package com.cg.ibs.spmgmt.ui;

import java.math.BigInteger;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.cg.ibs.spmgmt.bean.ServiceProvider;
import com.cg.ibs.spmgmt.exception.IBSException;
import com.cg.ibs.spmgmt.exception.RegisterException;
import com.cg.ibs.spmgmt.service.ServiceProviderService;
import com.cg.ibs.spmgmt.service.ServiceProviderServiceImpl;

public class Application {

	public static final Logger LOGGER = Logger.getLogger(Application.class);
	static String DIGIT_MESSAGE = "Enter a digit!";

	// Main-------------------------------------------------------
	public static void main(String[] args) {
		Application application = new Application();
		Scanner scanner = new Scanner(System.in);
		int switchInput = 0;
		boolean exitTrigger = true;
		// Keep Showing the menu until exit button pressed
		do {
			ServiceProviderService service = new ServiceProviderServiceImpl();
			if (!service.isRunnable()) {
				System.out.println("CONNECTION PROBLEM");
				break;
			}
			ServiceProvider serviceProvider = new ServiceProvider();
			switchInput = application.menu(scanner);
			switch (switchInput) {
			case 1:
				LOGGER.info("The user gave an invalid input while registering his details");
				// Takes User Input for all details-->performs basic input
				// checks
				application.registerServiceProvider(scanner, service, serviceProvider);
				application.returnToMainMenu(scanner);
				break;
			case 2:
				// Takes login ID and password--> checks validity-->shows
				// status/SPI if approved
				try {
					application.loginMethod(scanner, service, serviceProvider);
				} catch (IBSException e1) {
					System.out.println(e1.getMessage());
				}
				application.returnToMainMenu(scanner);
				break;
			case 3:
				// BankAdmin Login
				boolean exitToMain = false;
				exitToMain = application.bankAdmin(scanner, service);
				if (!exitToMain) {
					System.out.println("---------------Login Sucessful-----------------");
					// Getting the list of pending Service Providers in Database
					ArrayList<ServiceProvider> serviceProviders = new ArrayList<>();
					ArrayList<ServiceProvider> serviceProviders2 = new ArrayList<>();
					try {
						application.bankMethod(serviceProviders, serviceProviders2, service, scanner);
					} catch (IBSException exception) {
						LOGGER.info("The user gave an invalid input while logging as a bank admin");
						System.out.println(exception.getMessage());
					}
				}
				break;
			case 4:
				// Exit from Application
				exitTrigger = false;
				break;
			default:
				System.out.println("Invalid Input");
			}
		} while (exitTrigger);
		System.out.println("EXITED");
	}

	// Methods
	// Display Main Menu
	private int menu(Scanner scanner) {
		System.out.println("Welcome to Service Provider Portal");
		System.out.println("Select an option below (1/2/3/4):");
		System.out.println("1. New Registration");
		System.out.println("2. Login");
		System.out.println("3. Bank Administrator Login");
		System.out.println("4. Exit");
		// Ensuring input matches the menu
		while (!scanner.hasNextInt()) {
			scanner.next();
			scanner.nextLine();
			System.out.println("Invalid Input! Please Enter a Number: 1 2 3 4");
		}
		int returnInput = scanner.nextInt();
		scanner.nextLine();
		return returnInput;
	}

	// Register a user
	private void registerServiceProvider(Scanner scanner, ServiceProviderService service,
			ServiceProvider serviceProvider) {
		serviceProvider.setNameOfCompany(takeNameInput(scanner));
		try {
			// Generates Unique ID & Password
			serviceProvider = service.generateIdPassword(serviceProvider);
		} catch (Exception exception) {
			LOGGER.error("Error in generating Unique ID & Password");
			System.out.println(exception.getMessage());
		}
		System.out.println("Note Down the ID & Password for future logins:");
		System.out.println("User ID:" + serviceProvider.getUserId());
		System.out.println("Password: " + serviceProvider.getPassword());
		// Take Details with basic pattern matching
		serviceProvider = getKYC(scanner, serviceProvider);
		try {
			// store the object into database
			service.storeSPDetails(serviceProvider);
			System.out.println("\nREGISTRATION COMPLETE. APPROVAL REQUEST SENT TO BANK! "
					+ "\nLOGIN FROM MAIN MENU TO CHECK STATUS OF REQUEST \n");
		} catch (RegisterException exception) {
			System.out.println("------------------------------------------------------ \n" + exception.getMessage()
					+ "\n------------------------------------------------------");
			LOGGER.error("Error occured during registration");
		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}
	}

	// Input character length check
	private String takeNameInput(Scanner scanner) {
		String string = "";
		String namePattern = "[A-Z,a-z]{5}[ ,A-Z,a-z,0-9]{0,}";
		// Keep Taking User Input until it matches the pattern
		do {
			System.out.println("Enter Name of the Company(Minimum 5 Characters with no Spaces)");
			string = scanner.nextLine();
		} while (!string.matches(namePattern));
		return string;
	}

	// Taking KYC details and doing basic input checks to match standard
	// patterns
	private ServiceProvider getKYC(Scanner scanner, ServiceProvider serviceProvider) {

		System.out.println("\n------Enter the Necessary Details----- ");

		System.out.println("Select a category of Service Providers as applicable (1/2/3/4/5):");
		System.out.println("1. Telecom Services");
		System.out.println("2. Financial Services");
		System.out.println("3. Electricity");
		System.out.println("4. Dining Services");
		System.out.println("5. Travel Services");

		int categoryInput;
		do {
			inputLoop(scanner);
			categoryInput = scanner.nextInt();
			scanner.nextLine();
			switch (categoryInput) {
			case 1:
				serviceProvider.setCategory("Telecom Services");
				break;
			case 2:
				serviceProvider.setCategory("Financial Services");
				break;
			case 3:
				serviceProvider.setCategory("Electricity");
				break;
			case 4:
				serviceProvider.setCategory("Dining Services");
				break;
			case 5:
				serviceProvider.setCategory("Travel Services");
				break;
			default:
				System.out.println("Invalid Input! Enter 1/2/3/4/5");
			}
		} while (categoryInput > 5 || categoryInput < 1);

		return inputLoop2(scanner, serviceProvider);
	}

	// BankAdmin Login Inputs
	private boolean bankAdmin(Scanner scanner, ServiceProviderService service) {
		boolean validity = false;
		boolean exitToMain = false;
		// Taking Inputs until login succeeds
		do {
			System.out.println("Enter Admin ID: ");
			String inputId = scanner.next();
			scanner.nextLine();
			System.out.println("Enter Admin Password: ");
			String inputPassword = scanner.next();
			scanner.nextLine();
			int response;
			try {
				validity = service.validateAdminLogin(inputId, inputPassword);
			} catch (IBSException exception) {
				System.out.println(exception.getMessage());
				LOGGER.info("The Bank Admin gave an invalid input while logging in");
				System.out.println("Enter 1 to return back to main menu or enter any other digit to Try Again");
				integerLoop(scanner);
				response = scanner.nextInt();
				if (response == 1) {
					exitToMain = true;
					break;
				}

			}
		} while (!validity);
		return exitToMain;

	}

	// Prints Details of a Service Provider
	private void printDetails(ServiceProvider serviceProvider) {
		System.out.println("Name of Company: " + serviceProvider.getNameOfCompany());
		System.out.println("GST Number: " + serviceProvider.getGstin());
		System.out.println("PAN: " + serviceProvider.getPanNumber());
		System.out.println("Account Number: " + serviceProvider.getAccountNumber());
		System.out.println("Bank Name:" + serviceProvider.getBankName());
		System.out.println("Company Address: " + serviceProvider.getCompanyAddress());
		System.out.println("Mobile Number: " + serviceProvider.getMobileNumber());
	}

	// Shows all Pending Service Providers and allows to approve/disapprove
	private void bankMethod(ArrayList<ServiceProvider> serviceProviders, ArrayList<ServiceProvider> serviceProviders2,
			ServiceProviderService service, Scanner scanner) throws IBSException {
		int index = 0;
		boolean exitTrigger2 = true;
		do {
			service = new ServiceProviderServiceImpl();
			System.out.println(" Press 1 for pending List  Press 2 to view Request History 3 to exit ");
			integerLoop(scanner);
			switch (scanner.nextInt()) {
			// Show List of Pending Service Providers -> Allow to select from list and show
			// details -> Approve/Disapprove the selected one
			case 1:
				// Getting Pending list from database
				serviceProviders = service.showPending();
				try {
					if (service.emptyData()) {
						System.out.println("*******No pending accounts*********" + " \n RETURNING TO MAIN MENU!");
						break;
					}
				} catch (IBSException exception) {
					LOGGER.error("Get Pending list from Database Failed!");
					System.out.println(exception.getMessage());
				}
				System.out.println("List of Pending Accounts: ");
				System.out.println("Select an Account from the list below");
				DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
				for (index = 0; index < serviceProviders.size(); index++) {
					ServiceProvider value = serviceProviders.get(index);
					System.out.println((index + 1) + ". " + value.getNameOfCompany()+"( User ID =" + value.getUserId() + ")" + "\t Request Date and Time: "
							+ value.getRequestDate().format(format));
				}
				// Show selected Service Providers details -> Approve/Disapprove and update in
				// database
				updateServiceProvider(scanner, index, serviceProviders, service);
				break;
			// Show the past list of Service Providers with status either
			// Approved/Disapproved
			case 2:
				serviceProviders2 = service.showHistory();
				showHistory(serviceProviders2);
				break;
			// Exit to Main Menu
			case 3:
				exitTrigger2 = false;
				break;
			default:
				System.out.println("Invalid Input");
				break;
			}
		} while (exitTrigger2);
	}

	private void updateServiceProvider(Scanner scanner, int index, ArrayList<ServiceProvider> serviceProviders,
			ServiceProviderService service) {
		integerLoop(scanner);
		int k = scanner.nextInt();
		while (k > serviceProviders.size()) {
			System.out.println("Invalid input. Choose the correct number from menu to display company details!");
			integerLoop(scanner);
			k = scanner.nextInt();
			scanner.nextLine();
		}
		for (index = 0; index <= serviceProviders.size(); index++) {
			if ((index + 1) == k) {
				ServiceProvider value = serviceProviders.get(index);
				printDetails(value);
				System.out.println("Enter true to Approve, false to Disapprove");
				try {
					while (!scanner.hasNextBoolean()) {
						System.out.println("Enter true or false!");
						scanner.next();
						scanner.nextLine();
					}
					service.approveSP(value, scanner.nextBoolean());
					scanner.nextLine();
				} catch (IBSException exception) {
					LOGGER.error("boolean is being not entered by bank admin");
					System.out.println(exception.getMessage());
				}
				serviceProviders.remove((index));
				break;
			}
		}
	}

	private void showHistory(ArrayList<ServiceProvider> serviceProviders2) {
		int idx = 1;
		DateTimeFormatter format1 = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
		if (serviceProviders2.isEmpty()) {
			System.out.println("*******No history Found*********" + "\n RETURNING TO MAIN MENU! \n");
		} else {
			System.out.println("-----------REGISTRATION RECORDS--------------");
			for (ServiceProvider serviceProvider : serviceProviders2) {
				System.out.println(
						idx + ". " + serviceProvider.getNameOfCompany()+"( User ID =" + serviceProvider.getUserId() + ")" + "\t Status " + serviceProvider.getStatus()
								+ "\t Request Date and Time: " + serviceProvider.getRequestDate().format(format1)
								+ ((serviceProvider.getStatus().equals("Approved"))
										? "  Unique SPI: " + serviceProvider.getSpi()
										: ""));
				idx++;
			}
		}
	}

	// Taking 1 as input
	private void returnToMainMenu(Scanner scanner) {
		System.out.println("Enter a single digit number to return to main menu");
		integerLoop(scanner);
		scanner.nextInt();
		scanner.nextLine();
	}

	// Displays details and approval status
	private void loginMethod(Scanner scanner, ServiceProviderService service, ServiceProvider serviceProvider)
			throws IBSException {
		boolean exitTrig = true;
		serviceProvider = null;
		boolean exitToMain = false;
		do {
			System.out.println("Enter User ID: ");
			String inputId = scanner.next();
			scanner.nextLine();
			System.out.println("Enter Password: ");
			String inputPassword = scanner.next();
			scanner.nextLine();
			int response;
			boolean check = false;
			try {
				check = service.validateLogin(inputId, inputPassword);
			} catch (IBSException exception) {
				System.out.println(exception.getMessage());
				LOGGER.info("The user gave an invalid input while logging as a service provider");
				System.out.println("Enter 1 to return back to main menu or enter any other digit to Try Again");

				while (!scanner.hasNextInt()) {
					System.out.println(DIGIT_MESSAGE);
					scanner.next();
					scanner.nextLine();
				}
				response = scanner.nextInt();
				if (response == 1) {
					exitToMain = true;
					break;
				}

			}
			if (check) {
				try {
					serviceProvider = service.getServiceProvider(inputId);
				} catch (IBSException exception) {
					LOGGER.error("invalid input is being given to fetch details");
					System.out.println(exception.getMessage());
				} finally {
					exitTrig = (serviceProvider == null);
				}
			}
		} while (exitTrig);
		if (!exitToMain) {
			System.out.println("-------------Login Succesful------------------");
			printDetails(serviceProvider);
			System.out.println("Approval Status: " + serviceProvider.getStatus());
			if (serviceProvider.getStatus().equals("Approved")) {
				System.out.println("Unique SPI: " + serviceProvider.getSpi());
			}
		}
	}

	private void inputLoop(Scanner scanner) {
		while (!scanner.hasNextInt()) {
			scanner.next();
			scanner.nextLine();
			System.out.println("Invalid Input! Please Enter a Number: 1 2 3 4 5");
		}
	}

	private void integerLoop(Scanner scanner) {
		while (!scanner.hasNextInt()) {
			scanner.next();
			scanner.nextLine();
			System.out.println(DIGIT_MESSAGE);
		}
	}

	private ServiceProvider inputLoop2(Scanner scanner, ServiceProvider serviceProvider) {
		boolean bn = false;
		String string = "";
		String gstinPattern = "[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][0-9][A-Z][0-9,A-Z]";
		String panPattern = "[A-Z]{5}[0-9]{4}[A-Z]";
		String acNumberPattern = "[1-9][0-9]{9,14}";
		String phoneNumberPattern = "[1-9][0-9]{9}";
		System.out.println("Enter GST Number(16 Characters digit or uppercase alphabets): \nEx. 35AABCD1429B1ZX");
		do {
			string = scanner.next();
			scanner.nextLine();
			bn = !Pattern.matches(gstinPattern, string);
			if (bn) {
				System.out.println("Enter valid number(16 Characters-digits/uppercase letters)");
			}
		} while (bn);
		serviceProvider.setGstin(string);
		System.out.println("Enter PAN(10 Characters-digits/uppercase letters): \nEx: AAAPL1234C ");
		do {
			string = scanner.next();
			scanner.nextLine();
			bn = !Pattern.matches(panPattern, string);
			if (bn) {
				System.out.println("Enter valid PAN(10 Characters-digits/uppercase letters)");
			}
		} while (bn);
		serviceProvider.setPanNumber(string);
		System.out.println("Enter Bank Account Number(10-14 digits): ");
		do {
			string = scanner.next();
			scanner.nextLine();
			bn = !Pattern.matches(acNumberPattern, string);
			if (bn) {
				System.out.println("Enter a valid Account number(10-14 digits)");
			}
		} while (bn);
		serviceProvider.setAccountNumber((new BigInteger(string)));
		System.out.println("Enter Name of the Bank: ");
		serviceProvider.setBankName(scanner.nextLine());
		System.out.println("Enter Company Address: ");
		serviceProvider.setCompanyAddress(scanner.nextLine());
		System.out.println("Enter Contact Number (10 digits): ");
		do {
			string = scanner.next();
			scanner.nextLine();
			bn = !Pattern.matches(phoneNumberPattern, string);
			if (bn) {
				System.out.println(
						"Enter 10 digit phone number that doesn't start with 0(No special characters like + or -)");
			}

		} while (bn);
		serviceProvider.setMobileNumber(new BigInteger(string));
		printDetails(serviceProvider);
		return serviceProvider;
	}
}
