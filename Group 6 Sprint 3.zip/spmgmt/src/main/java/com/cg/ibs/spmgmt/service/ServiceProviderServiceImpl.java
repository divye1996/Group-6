package com.cg.ibs.spmgmt.service;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;

import org.apache.log4j.Logger;

import com.cg.ibs.spmgmt.bean.BankAdmin;
import com.cg.ibs.spmgmt.bean.ServiceProvider;
import com.cg.ibs.spmgmt.dao.ServiceProviderDao;
import com.cg.ibs.spmgmt.dao.ServiceProviderDaoImpl;
import com.cg.ibs.spmgmt.exception.IBSException;
import com.cg.ibs.spmgmt.exception.IBSExceptionInterface;
import com.cg.ibs.spmgmt.exception.RegisterException;

public class ServiceProviderServiceImpl implements ServiceProviderService {
	public static final Logger LOGGER = Logger.getLogger(ServiceProviderServiceImpl.class);
	static ServiceProviderDao serviceProviderDao = new ServiceProviderDaoImpl();
	ServiceProvider serviceProvider = new ServiceProvider();
	private static BigInteger spi = BigInteger.valueOf(-1);
	private static boolean runnable = true;

	public boolean isRunnable() {
		return runnable;
	}

	static {
		try {
			spi = serviceProviderDao.getLastSPI();
		} catch (IBSException e) {
			runnable = false;
			LOGGER.error("DATABASE NOT FOUND/CONNECTION FAILURE");
		}
		if (spi.compareTo(BigInteger.valueOf(100000)) < 0) {
			spi = BigInteger.valueOf(100000);
		}
	}

	// Function to generate User ID and Password of Service Provider
		@Override
		public ServiceProvider generateIdPassword(ServiceProvider serviceProvider) throws RegisterException, IBSException {
			String temp =serviceProvider.getNameOfCompany();
			String userId= temp.substring(0,5);
			boolean userIdExists = false;
			long tail= 1;
			if(userIdExists= ((serviceProviderDao.checkUserId(userId)).equals(userId))) {
				String tempuser =userId;
				do {
					userId= tempuser + "_" +Long.toString(tail);
					userIdExists = ((serviceProviderDao.checkUserId(userId)).equals(userId));
					tail++;
				} while (userIdExists);
			}
			
			String passGeneratorSet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789" + "abcdefghijklmnopqrstuvxyz"
					+ "!@#$%^&*_=+-/.?<>)";
			StringBuilder userPass = new StringBuilder(8);

			for (int i = 0; i < 8; i++) {
				int index = (int) (passGeneratorSet.length() * Math.random());
				userPass.append(passGeneratorSet.charAt(index));
			}

			String result = userPass.toString();
			serviceProvider.setUserId(userId);
			serviceProvider.setPassword(result);
			return serviceProvider;
		}

	// Function to store details of Service Provider
	@Override
	public boolean storeSPDetails(ServiceProvider sp) throws RegisterException, IBSException {
		boolean result = false;
		if (sp == null) {
			throw new IBSException("No Service Provider Passed");
		}
		sp.setRequestDate(LocalDateTime.now());
		String encode= Base64.getEncoder() 
                .encodeToString((sp.getPassword()).getBytes());
		sp.setPassword(encode);
		ServiceProvider storeResult = serviceProviderDao.addServiceProvider(sp); // used to store the SP details after
																					// // registration
		if (storeResult != null)
			result = true;
		return result;
	}

	// Function to validate Login of Service Provider
	@Override
	public boolean validateLogin(String username, String password) throws IBSException {
		boolean result = false;
		serviceProvider = serviceProviderDao.getServiceProviderById(username);
		String encode= serviceProvider.getPassword();
		byte[] decode= Base64.getDecoder() 
                .decode(encode);
		String decodePassword= new String(decode);
		serviceProvider.setPassword(decodePassword);
		if (serviceProvider.getPassword() != null) {
			if (password.equals(serviceProvider.getPassword())) {
				result = true;
			} else {
				throw new IBSException(IBSExceptionInterface.INCORRECT_LOGIN_MESSAGE);
			}
		} else {
			throw new IBSException(IBSExceptionInterface.INCORRECT_LOGIN_MESSAGE);
		}
		return result;
	}

	// Function to get the details of Service Provider from DAO Layer where the
	// details are stored
	@Override
	public ServiceProvider getServiceProvider(String userid) throws IBSException {
		serviceProvider = serviceProviderDao.getServiceProviderById(userid);
		return serviceProvider;
	}

	// Function to show all the Pending Request of Service Providers to the Bank
	// Administrative
	@Override
	public ArrayList<ServiceProvider> showPending() throws IBSException {
		return serviceProviderDao.getPendingServiceProviders();
	}

	// Function to approve or disapprove the request of Service Provider by the Bank
	// Administrative
	@Override
	public void approveSP(ServiceProvider sp, boolean decision) throws IBSException {
		if (decision) {
			sp.setStatus("Approved");
			generateSpi();
			sp.setSpi(spi);
		} else {
			sp.setStatus("Disapproved");
		}
		serviceProviderDao.updateServiceProvider(sp);
	}

	// Function to get the details of all the Approved Service Providers to be used
	// by Remittance Management

	// Function to generate Unique SPI ID after the Service Provider gets approved
	private static BigInteger generateSpi() {
		spi = spi.add(BigInteger.valueOf(1));
		return spi;
	}

	// Function to validate the login of bank Administrative
	@Override
	public boolean validateAdminLogin(String adminID, String adminPassword) throws IBSException {
		boolean validity = false;
		BankAdmin admin;
		admin = serviceProviderDao.getBankAdmin(adminID);
		if (admin.getAdminPassword() != null) {
			if (adminPassword.equals(admin.getAdminPassword())) {
				validity = true;
			} else {
				throw new IBSException(IBSExceptionInterface.INCORRECT_LOGIN_MESSAGE);
			}
		} else {
			throw new IBSException(IBSExceptionInterface.INCORRECT_LOGIN_MESSAGE);
		}
		return validity;
	}

	// Default empty data function
	@Override
	public boolean emptyData() throws IBSException {
		return (serviceProviderDao.getPendingServiceProviders().isEmpty());
	}

	@Override
	public ArrayList<ServiceProvider> showHistory() throws IBSException {
		ArrayList<ServiceProvider> historyList = serviceProviderDao.getApprovedDisapprovedServiceProviders();
		Collections.sort(historyList, (serviceProvider1, serviceProvider2) -> serviceProvider1.getRequestDate()
				.compareTo(serviceProvider2.getRequestDate()));
		return historyList;
	}
}
