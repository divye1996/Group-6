package com.cg.ibs.spmgmt.bean;

public class Register {
	public Register(String nameOfCompany, String panNumber) {
		super();
		this.nameOfCompany = nameOfCompany;
		this.panNumber = panNumber;
	}
	public Register() {
		// TODO Auto-generated constructor stub
	}
	private String nameOfCompany;
	private String panNumber;
	
	@Override
	public String toString() {
		return "Register [nameOfCompany=" + nameOfCompany + ", panNumber=" + panNumber + "]";
	}
	public String getNameOfCompany() {
		return nameOfCompany;
	}
	public void setNameOfCompany(String nameOfCompany) {
		this.nameOfCompany = nameOfCompany;
	}
	public String getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

}
