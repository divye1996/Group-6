package com.cg.ibs.spmgmt.exception;

public interface IBSExceptionInterface {
	public static String ALREADY_EXISTS_MESSAGE  = "Username already exists. Change username and try Registration again!";
	public static String INCORRECT_PASSWORD_MESSAGE  = "INCORRECT USERID / PASSWORD";
	
}
