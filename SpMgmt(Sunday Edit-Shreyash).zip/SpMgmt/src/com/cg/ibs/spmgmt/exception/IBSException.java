package com.cg.ibs.spmgmt.exception;

public class IBSException extends Exception {
	public IBSException(String message) {
		super(message);
	}

}
