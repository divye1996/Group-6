package com.cg.ibs.spmgmt.ui;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Pattern;
import com.cg.ibs.spmgmt.bean.BankAdmin;
import com.cg.ibs.spmgmt.bean.ServiceProvider;
import com.cg.ibs.spmgmt.exception.IBSException;
import com.cg.ibs.spmgmt.exception.RegisterException;
import com.cg.ibs.spmgmt.service.ServiceProviderService;
import com.cg.ibs.spmgmt.service.ServiceProviderServiceImpl;

public class Application {
	// Main-------------------------------------------------------
	public static void main(String[] args) {
		Application application = new Application();
		Scanner scanner = new Scanner(System.in);
		BankAdmin admin = new BankAdmin();
		int switchInput = 0;
		boolean exitTrigger = true;
		do {
			ServiceProviderService service = new ServiceProviderServiceImpl();
			ServiceProvider serviceProvider = new ServiceProvider();
			switchInput = application.menu(scanner);
			switch (switchInput) {
			case 1:
				application.registerServiceProvider(scanner, service, serviceProvider);
				application.returnToMainMenu(scanner);
				break;
			case 2:
				application.loginMethod(scanner, service, serviceProvider);
				application.returnToMainMenu(scanner);
				break;
			case 3:
				application.bankAdmin(scanner, admin, service);
				TreeMap<LocalDateTime, ServiceProvider> serviceProviders = service.showPending();
				application.bankMethod(scanner, serviceProviders, service);
				break;
			case 4:
				exitTrigger = false;
				break;
			default:
				System.out.println("Invalid Input");
			}
		} while (exitTrigger);
	}

	// Methods
	// Display Main Menu
	private int menu(Scanner scanner) {
		System.out.println("Welcome to Service Provider Portal");
		System.out.println("Select an option below (1/2/3/4):");
		System.out.println("1. New Registration");
		System.out.println("2. Login");
		System.out.println("3. Bank Administrator Login");
		System.out.println("4. Exit");
		while (!scanner.hasNextInt()) {
			scanner.next();
			System.out.println("Invalid Input! Please Enter a Number: 1 2 3 4");
		}
		return scanner.nextInt();
	}

	// Register a user
	private void registerServiceProvider(Scanner scanner, ServiceProviderService service,
			ServiceProvider serviceProvider) {
		serviceProvider.setNameOfCompany(takeNameInput(scanner));
		try {
			serviceProvider = service.generateIdPassword(serviceProvider);
		} catch (RegisterException e) {
			e.printStackTrace();
		}
		System.out.println("Note Down the ID & Password for future logins:");
		System.out.println("User ID:" + serviceProvider.getUserId());
		System.out.println("Password: " + serviceProvider.getPassword());
		serviceProvider = getKYC(scanner, serviceProvider);
		try {
			service.storeSPDetails(serviceProvider);
		} catch (IBSException e) {
			e.printStackTrace();
		}
	}

	// Input character length check
	private String takeNameInput(Scanner scanner) {
		String string = "";
		String namePattern = "[A-Z,a-z]{5,10}";
		do {
			System.out.println("Enter Name of the Company(Minimum 5 Characters)");
			string = scanner.next();
		} while (!string.matches(namePattern));
		return string;
	}

	// Taking KYC details and doing basic input checks to match standard patterns
	private ServiceProvider getKYC(Scanner scanner, ServiceProvider serviceProvider) {
		boolean bn = false;
		String st = "";
		String gstinPattern = "[0-9,A-Z]{10,16}";
		String panPattern = "[0-9,A-Z]{10}";
		String acNumberPattern = "[0-9]{10,14}";
		String phoneNumberPattern = "[1-9][0-9]{9}";
		System.out.println("\n------Enter the Necessary Details----- ");
		System.out.println("Enter GST Number: ");
		do {
			st = scanner.next();
			bn = !Pattern.matches(gstinPattern, st);
			if (bn) {
				System.out.println("Enter valid number");
			}
		} while (bn);
		serviceProvider.setGstin(st);
		System.out.println("Enter PAN: ");
		do {
			st = scanner.next();
			bn = !Pattern.matches(panPattern, st);
			if (bn) {
				System.out.println("Enter valid PAN");
			}
		} while (bn);
		serviceProvider.setPanNumber(st);
		System.out.println("Enter Bank Account Number: ");
		do {
			st = scanner.next();
			bn = !Pattern.matches(acNumberPattern, st);
			if (bn) {
				System.out.println("Enter a valid Account number");
			}
		} while (bn);
		serviceProvider.setAccountNumber((new BigInteger(st)));
		System.out.println("Enter Name of the Bank: ");
		serviceProvider.setBankName(scanner.next());
		System.out.println("Enter Company Address: ");
		serviceProvider.setCompanyAddress(scanner.next());
		System.out.println("Enter Contact Number: ");
		do {
			st = scanner.next();
			bn = !Pattern.matches(phoneNumberPattern, st);
			if (bn) {
				System.out.println("Enter 10 digit phone number");
			}
		} while (bn);
		serviceProvider.setMobileNumber(new BigInteger(st));
		printDetails(serviceProvider);
		return serviceProvider;
	}

	// BankAdmin Login Inputs
	private void bankAdmin(Scanner scanner, BankAdmin admin, ServiceProviderService service) {
		boolean exitTrig = true;
		do {
			System.out.println("Enter Admin ID: ");
			admin.setAdminID(scanner.next());
			System.out.println("Enter Admin Password: ");
			admin.setAdminPassword(scanner.next());
			try {
				exitTrig = !service.validateAdminLogin(admin.getAdminID(), admin.getAdminPassword());
			} catch (IBSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} while (exitTrig);
		System.out.println("---------------Login Sucessful-----------------");
	}

	// Prints Details of a Service Provider
	private void printDetails(ServiceProvider serviceProvider) {
		System.out.println("Name of Company: " + serviceProvider.getNameOfCompany());
		System.out.println("GST Number: " + serviceProvider.getGstin());
		System.out.println("PAN: " + serviceProvider.getPanNumber());
		System.out.println("Account Number: " + serviceProvider.getAccountNumber());
		System.out.println("Bank Name:" + serviceProvider.getBankName());
		System.out.println("Company Address: " + serviceProvider.getCompanyAddress());
		System.out.println("Mobile Number: " + serviceProvider.getMobileNumber());
	}

	// Shows all Pending Service Providers and allows to approve/disapprove
	private void bankMethod(Scanner scanner, TreeMap<LocalDateTime, ServiceProvider> serviceProviders,
			ServiceProviderService service) {
		int i = 1;
		int k = 0;
		boolean exitTrigger2 = true;
		do {
			Set<LocalDateTime> keyz = serviceProviders.keySet();
			if (keyz.isEmpty()) {
				System.out.println("No pending accounts");
				break;
			}
			System.out.println("List of Pending Accounts: ");
			System.out.println("Select an Account from the list below");
			for (LocalDateTime key : keyz) {
				ServiceProvider value = serviceProviders.get(key);
				System.out.println(i + ". " + value.getNameOfCompany() + "Request Date and Time: " + key);
				i++;
			}
			k = scanner.nextInt();
			i = 1;
			for (LocalDateTime key : keyz) {
				System.out.println(key);
				if (k == i) {
					ServiceProvider value = serviceProviders.get(key);
					printDetails(value);
					System.out.println("Enter true to Approve false to Disapprove");
					try {
						service.approveSP(value, scanner.nextBoolean());
					} catch (IBSException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					serviceProviders.remove(key);
					break;
				}
			}
			System.out.println(
					"Press 1 to see remaining pending accounts \nPress any other number to go back to Main Menu");
			if (scanner.nextInt() == 1) {
				exitTrigger2 = false;
			}
		} while (!exitTrigger2);
	}

	// Taking 1 as input
	private void returnToMainMenu(Scanner scanner) {
		System.out.println("Enter 1 to return to main menu");
		while (scanner.nextInt() != 1) {
		}
	}

	// Displays details and approval status
	private void loginMethod(Scanner scanner, ServiceProviderService service, ServiceProvider serviceProvider) {
		boolean exitTrig = true;
		do {
			System.out.println("Enter User ID: ");
			String inputId = scanner.next();
			System.out.println("Enter Password: ");
			String inputPassword = scanner.next();
			try {
				service.validateLogin(inputId, inputPassword);
			} catch (IBSException e) {
				e.printStackTrace();
			}
			try {
				serviceProvider = service.getServiceProvider(inputId);
			} catch (IBSException e) {
				e.printStackTrace();
			} finally {
				exitTrig = (serviceProvider == null);
			}
		} while (exitTrig);
		System.out.println("-------------Login Succesfull------------------");
		printDetails(serviceProvider);
		System.out.println(serviceProvider.toString());
		System.out.println("Approval Status: " + serviceProvider.getStatus());
		if (serviceProvider.getStatus().equals("Approved")) {
			System.out.println(serviceProvider.getSpi());
		}
	}
}
