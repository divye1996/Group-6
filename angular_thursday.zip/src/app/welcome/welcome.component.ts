import { Component, OnInit } from '@angular/core';
import { ServiceProvider } from '../model/service-provider';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {
  
    serviceProvider : ServiceProvider;
    constructor() { 
      this.serviceProvider = new ServiceProvider();
   
    }
   
    ngOnInit() {
      this.load();
    }
   
    load(){
      this.serviceProvider = JSON.parse(localStorage.getItem('serviceProvider'));
    }
   
  }
