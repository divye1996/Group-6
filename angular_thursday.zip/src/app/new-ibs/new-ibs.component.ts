import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-ibs',
  templateUrl: './new-ibs.component.html',
  styleUrls: ['./new-ibs.component.css']
})
export class NewIbsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
