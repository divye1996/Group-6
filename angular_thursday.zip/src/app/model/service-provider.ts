export class ServiceProvider {
    
    public accountNumber : BigInteger ;
 
    
    public applicantId : BigInteger;
 
    public addressProofUpload : File ;
 
    
    public bankName : String;
 
    
    public category : String;
 
    
    public companyAddress : String;
    
    
    public gstin : String ;
 
    
    public ifsc : String;
    
    
    public mobileNumber : BigInteger;
 
    public nameOfCompany : String;
 
    
    public panCardUpload : File;
    
    
    public panNumber : String;
 
    public password : String;
 
    public remarks : String;
 
    public requestDate : Date ;
 
    
    public spi : BigInteger;
    
    
    public status : String;
 
    public userId : String;
    
 
}
