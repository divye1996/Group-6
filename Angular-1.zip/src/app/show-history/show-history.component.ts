import { Component, OnInit } from '@angular/core';
import { ServiceProvider } from '../model/service-provider.model';
import { SpService } from '../service/sp.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-show-history',
  templateUrl: './show-history.component.html',
  styleUrls: ['./show-history.component.css']
})
export class ShowHistoryComponent implements OnInit {
  serviceProviders  : ServiceProvider[];

  constructor(private spService: SpService , private router: Router) {
    this.serviceProviders = null;
   }

  ngOnInit() {
    this.history();
  }

  history(){
    this.spService.getHistory().subscribe(
      (data) => {
        this.serviceProviders = data;
      }
    )
  }
  

}
