import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { ServiceProvider } from '../model/service-provider.model';
import { BankResponse } from '../model/bank-response.model';

@Injectable({
  providedIn: 'root'
})
export class SpService {

  baseUrl:string;
  constructor(private http:HttpClient) {
    this.baseUrl=`${environment.baseMwUrl}`;
  }

  provider: ServiceProvider;
  

  
  add(sp:ServiceProvider):Observable<ServiceProvider>{
    this.provider=sp;
    console.log("before sending: "+sp);
    return this.http.post<ServiceProvider>(`${this.baseUrl}/registeredDetails`,sp);
  }

  getById(userId:String):Observable<ServiceProvider>{
    console.log("getbyid"+userId);
    return this.http.get<ServiceProvider>(`${this.baseUrl}loginDetails/${userId}`);
  }

  getPendingList():Observable<ServiceProvider[]>{
    return this.http.get<ServiceProvider[]>(`${this.baseUrl}/pendingList`);
  }

  getHistory():Observable<ServiceProvider[]>{
    return this.http.get<ServiceProvider[]>(`${this.baseUrl}/showHistory`);
  }


  getStatus(bankResponse :BankResponse):Observable<any>{
 
    return this.http.post<any>(`${this.baseUrl}/updateSP`,bankResponse);
  }
 
  
  getDetails(serviceProvider:ServiceProvider):Observable<ServiceProvider>{
 
    return this.http.post<ServiceProvider>(`${this.baseUrl}/registeredDetails`,serviceProvider);
  }

}