export class BankResponse {
    public userId:String;
    public remarks:String;
    public decision: String;
}
