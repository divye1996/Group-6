import { Component, OnInit } from '@angular/core';
import { SpService } from '../service/sp.service';
import { ServiceProvider } from '../model/service-provider.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-pending-list',
  templateUrl: './pending-list.component.html',
  styleUrls: ['./pending-list.component.css']
})
export class PendingListComponent implements OnInit {
  serviceProviders : ServiceProvider[];

  constructor(private spService : SpService , private router : Router) {
    this.serviceProviders = [];

   }

  ngOnInit() {
  this.load();
  }

load(){
  
  this.spService.getPendingList().subscribe(
    (data) => {
      this.serviceProviders = data;
    } 
  )
}
}
