import { SpService } from './../service/sp.service';
import { AppComponent } from './../app.component';
import { ServiceProvider } from './../model/service-provider.model';
import { Component } from '@angular/core';


@Component({
  selector: 'app-new-registration-form',
  templateUrl: './new-registration-form.component.html',
  styleUrls: ['./new-registration-form.component.css']
})
export class NewRegistrationFormComponent {

  serviceProvider = new ServiceProvider();
  submitted = false;
  confirmSubmit=false;
  categories = ["Telecom Services", "Financial Services", "Electricity", "Dining Services", "Travel Service"];
  ;

  constructor(private service: SpService) {
  }

  onSubmit() {
    this.submitted = true;
  }

  nice() {
   this.confirmSubmit=true;
   this.service.add(this.serviceProvider).subscribe(
      (data) => {
        this.serviceProvider = data;
        console.log("After sending"+this.serviceProvider.userId);
        
      }
    );
    
    this.service.provider=this.serviceProvider;
  }
}