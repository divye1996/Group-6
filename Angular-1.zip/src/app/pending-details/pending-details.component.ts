import { Component} from '@angular/core';
import { ServiceProvider } from '../model/service-provider.model';
import { SpService } from '../service/sp.service';
import { BankResponse } from '../model/bank-response.model';
import { ActivatedRoute, Router } from '@angular/router';

 
 
@Component({
  selector: 'app-pending-details',
  templateUrl: './pending-details.component.html',
  styleUrls: ['./pending-details.component.css']
})
export class PendingDetailsComponent{
  remarks: string;
  userId: String;
  serviceProvider : ServiceProvider;
  bankResponse : BankResponse;

  constructor(private sPService: SpService ,private router:Router,private route: ActivatedRoute) {
    this.route.queryParams.subscribe(params => {
      this.userId=params['uid'];
            console.log("UID:"+this.userId);
        })
        console.log("UID2:"+this.userId);    
    this.serviceProvider = new ServiceProvider();
    this.remarks="";
    this.bankResponse = new BankResponse();
    this.login();
  }
 
  login() {
    console.log("Login"+this.userId);
    this.sPService.getById(this.userId).subscribe(
      (data) => {
        this.serviceProvider = data;
        console.log(data);
      }
      
    );
  }
 
  load(){
    console.log("here1");
    this.sPService.getById(this.userId).subscribe(
      (data)=>{
        this.serviceProvider =data;
        console.log("here2");
      }
    )
    console.log("here3");
  }
  approve()

  {
    if(confirm("Are u sure you want to approve")){
    this.bankResponse.decision="Approved";
    this.bankResponse.remarks=this.remarks;
    this.bankResponse.userId =this.userId;
 
 
    this.sPService.getStatus(this.bankResponse).subscribe(
 
      (data) => {
        this.serviceProvider = data;
         this.router.navigateByUrl("pendingList");
        
      }
      
    );
 
    }
        
 
  }
  disapprove(){
    localStorage.setItem('remarks', this.remarks);
    localStorage.setItem('status', "Disapproved");
 
  }
}