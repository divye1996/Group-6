package com.cg.dw.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dw.dao.DepartmentRepository;
import com.cg.dw.model.Department;

@Service
public class DepartmentServiceImpl implements DepartmentService{

	@Autowired
	private DepartmentRepository deptRepo;
	
	@Transactional
	@Override
	public Department add(Department dept) {
		return deptRepo.add(dept);
	}

	@Transactional
	@Override
	public Department save(Department dept) {
		return deptRepo.save(dept);
	}

	@Override
	public Department findById(Long deptId) {
		return deptRepo.findById(deptId);
	}

	@Override
	public List<Department> findAll() {
		return deptRepo.findAll();
	}

	@Override
	public List<Department> findAllByName(String dName) {
		return deptRepo.findAllByName(dName);
	}

}
