import { ServiceProvider } from './service-provider';

describe('ServiceProvider', () => {
  it('should create an instance', () => {
    expect(new ServiceProvider()).toBeTruthy();
  });
});
