import { Component, OnInit } from '@angular/core';
import { ServiceProvider } from '../model/service-provider';
import { ServiceProviderService } from '../service/service-provider.service';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-splogin',
  templateUrl: './splogin.component.html',
  styleUrls: ['./splogin.component.css']
})
export class SploginComponent implements OnInit {
  serviceProviders : ServiceProvider[];
  serviceProvider : ServiceProvider;

  constructor(private sPServ: ServiceProviderService,private router: Router)  {
    this.serviceProviders= [];
    this.serviceProvider = new ServiceProvider();
  }

  ngOnInit() {
    this.load();
  }
  load() {
    this.sPServ.getById(this.serviceProvider.userId).subscribe(
      (data) => { this.serviceProvider = data; 
        this.router.navigateByUrl("/otherbankregister");
      }
    );
  }

}
