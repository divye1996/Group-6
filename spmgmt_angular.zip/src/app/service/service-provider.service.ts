import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { ServiceProvider} from '../model/service-provider';

@Injectable({
  providedIn: 'root'
})
export class ServiceProviderService {

  baseUrl:string;
  

  constructor(private http: HttpClient) {
    this.baseUrl=`${environment.baseMwUrl}`;
  }
  add(sp:ServiceProvider):Observable<ServiceProvider>{
    return this.http.post<ServiceProvider>(`${this.baseUrl}/registeredDetails`,JSON.stringify(sp));
  }
  getById(userId:String):Observable<any>{
    return this.http.get<ServiceProvider>(`${this.baseUrl}/${userId}`);
  }
  
}
