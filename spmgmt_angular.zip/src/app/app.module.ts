import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { GroupsComponent } from './groups/groups.component';
import { ContactsListComponent } from './contacts-list/contacts-list.component';
import { ContactFormComponent } from './contact-form/contact-form.component';
import { SearchContactComponent } from './search-contact/search-contact.component';
import { OtherbankComponent } from './otherbank/otherbank.component';
import { ExistingIbsComponent } from './existing-ibs/existing-ibs.component';
import {NewIbsComponent} from './new-ibs/new-ibs.component';
import { SploginComponent } from './splogin/splogin.component';
import { BankerloginComponent } from './bankerlogin/bankerlogin.component';




@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    GroupsComponent,
    ContactsListComponent,
    ContactFormComponent,
    SearchContactComponent,
    OtherbankComponent,
    ExistingIbsComponent,
    NewIbsComponent,
    SploginComponent,
    BankerloginComponent,
   
  

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
