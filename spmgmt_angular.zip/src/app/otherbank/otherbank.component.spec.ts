import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtherbankComponent } from './otherbank.component';

describe('OtherbankComponent', () => {
  let component: OtherbankComponent;
  let fixture: ComponentFixture<OtherbankComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtherbankComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtherbankComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
