import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewIbsComponent } from './new-ibs.component';

describe('NewIbsComponent', () => {
  let component: NewIbsComponent;
  let fixture: ComponentFixture<NewIbsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewIbsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewIbsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
