package com.cg.ibs.spmgmt.exception;

public class RegisterException extends Exception {
	private static final long serialVersionUID = 4664456874499611218L;
	public RegisterException(String message) {
		super(message);
	}

}
