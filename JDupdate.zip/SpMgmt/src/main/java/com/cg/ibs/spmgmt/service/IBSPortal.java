package com.cg.ibs.spmgmt.service;

import java.util.ArrayList;

import com.cg.ibs.spmgmt.bean.ServiceProvider;

public interface IBSPortal {
	public ArrayList<ServiceProvider> getApprovedDetails();

}