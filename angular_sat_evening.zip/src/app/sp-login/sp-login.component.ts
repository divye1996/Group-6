import { Component, OnInit } from '@angular/core';
import { SpService } from '../service/sp.service';
import { ServiceProvider } from '../model/service-provider.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sp-login',
  templateUrl: './sp-login.component.html',
  styleUrls: ['./sp-login.component.css']
})
export class SpLoginComponent implements OnInit {

  userId: string;
  serviceProvider: ServiceProvider;
  postlogin=false;
  errorMsg:String;

  constructor(private spService: SpService, private router: Router) {
    this.userId = "";
    this.serviceProvider = null;
  }

  ngOnInit() {
    this.login();
  }

  login() {
    this.spService.getById(this.userId).subscribe(
      (data) => {
        this.serviceProvider = data;
        this.postlogin=true;
      },
      (error) =>{
        this.errorMsg = error;
        alert(this.errorMsg);
      }
      
      
    );
  }

}