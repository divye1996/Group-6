import { Component, OnInit} from '@angular/core';
import { ServiceProvider } from '../model/service-provider.model';
import { SpService } from '../service/sp.service';
import { BankResponse } from '../model/bank-response.model';
import { ActivatedRoute, Router } from '@angular/router';

 
 
@Component({
  selector: 'app-pending-details',
  templateUrl: './pending-details.component.html',
  styleUrls: ['./pending-details.component.css']
})
export class PendingDetailsComponent implements OnInit {
  remarks: string;
  userId: String;
  serviceProvider : ServiceProvider;
  bankResponse : BankResponse;
  message : String;
  approval=false;

  constructor(private sPService: SpService ,private router:Router,private route: ActivatedRoute) {
    this.route.queryParams.subscribe(params => {
      this.userId=params['uid'];
            console.log("UID:"+this.userId);
        })
        console.log("UID2:"+this.userId);    
    this.serviceProvider = new ServiceProvider();
    this.remarks="";
    this.bankResponse = new BankResponse();
    this.login();
    this.message = "";
  }

  ngOnInit() {
    if(!this.sPService.bankSubmit){
      this.router.navigateByUrl("banker");
    }}
 
  login() {
    console.log("Login"+this.userId);
    this.sPService.getById(this.userId).subscribe(
      (data) => {
        this.serviceProvider = data;
        console.log(data);
      }
      
    );
  }
 
  approve(decision:String)

  {
    if(confirm("?")){
    this.bankResponse.decision=decision;
    this.bankResponse.remarks=this.remarks;
    this.bankResponse.userId =this.userId;
    console.log("123");
    this.sPService.getStatus(this.bankResponse).subscribe(
      (data)=>{
        this.bankResponse=data;
        console.log(data);
        this.message = this.bankResponse.remarks;
        this.approval=true;
      }
    )};   
    }
}