import { Component, OnInit } from '@angular/core';
import { ServiceProvider } from '../model/service-provider';
import { ServiceProviderService } from '../service/service-provider.service';


@Component({
  selector: 'app-pending-list',
  templateUrl: './pending-list.component.html',
  styleUrls: ['./pending-list.component.css']
})
export class PendingListComponent implements OnInit {
  serviceProviders : ServiceProvider[];
  serviceProvider :ServiceProvider;
  userId : String;
  constructor(private sPServ :ServiceProviderService) { 
    this.serviceProviders = [];
    this.serviceProvider = new ServiceProvider;
  
 
  }
 
  ngOnInit() {
    this.getList();
   
  }
 
  getList(){
    this.sPServ.getPendingList().subscribe(
 (data) => {
   this.serviceProviders=data;
   
 }
    );
  }
  // load(){
  //   localStorage.setItem('serviceProvider', JSON.stringify(this.serviceProvider));
  // }
  // loadDetails() {
    
 
  //   this.sPServ.getById(this.userId).subscribe(
 
  //     (data) => {
  //       this.serviceProvider = data;
  //       localStorage.setItem('serviceProvider', JSON.stringify(this.serviceProvider));
  //       this.router.navigateByUrl("welcome");
  //     }
      
  //   );
  // }
}
