export class Bankresponse {
    public userId:string;
    public remarks:string;
    public decision:string;
}
