import { Bankresponse } from './bankresponse';

describe('Bankresponse', () => {
  it('should create an instance', () => {
    expect(new Bankresponse()).toBeTruthy();
  });
});
