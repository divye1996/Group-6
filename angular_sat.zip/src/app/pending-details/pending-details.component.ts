import { Component, OnInit ,Input} from '@angular/core';
import { ServiceProvider } from '../model/service-provider';
import { ServiceProviderService } from '../service/service-provider.service';
// import { PendingListComponent } from '../pending-list/pending-list.component';

import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-pending-details',
  templateUrl: './pending-details.component.html',
  styleUrls: ['./pending-details.component.css']
})
export class PendingDetailsComponent implements OnInit {
  // remarks: string;
  serviceProvider: ServiceProvider;

 
  constructor(private sPServ: ServiceProviderService) { 
    this.serviceProvider = null;
    // this.remarks="";
 
 
  }
 
  ngOnInit() {
    this.load();
  }
 
  load(){
    this.serviceProvider = JSON.parse(localStorage.getItem('serviceProvider'));
  }
  // approve()
  // {
  //   localStorage.setItem('remarks', this.remarks);
  //   localStorage.setItem('decision', "Approved");


  //   this.sPServ.add(this.serviceProvider1).subscribe(
  //     (data) => {
  //       this.serviceProvider1 = data;
  //     }
  //   );
  //   this.sPServ.getStatus(this.serviceProvider1).subscribe(
 
  //     (data) => {
  //       this.serviceProvider = data;
  //       // localStorage.setItem('serviceProvider', JSON.stringify(this.serviceProvider));
  //       // this.router.navigateByUrl("welcome");
  //     }
      
  //   );

  // }
  // disapprove(){
  //   localStorage.setItem('remarks', this.remarks);
  //   localStorage.setItem('status', "Disapproved");


  // }
}
