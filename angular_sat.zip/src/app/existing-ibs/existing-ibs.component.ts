import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-existing-ibs',
  templateUrl: './existing-ibs.component.html',
  styleUrls: ['./existing-ibs.component.css']
})
export class ExistingIbsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
