import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExistingIbsComponent } from './existing-ibs.component';

describe('ExistingIbsComponent', () => {
  let component: ExistingIbsComponent;
  let fixture: ComponentFixture<ExistingIbsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExistingIbsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExistingIbsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
