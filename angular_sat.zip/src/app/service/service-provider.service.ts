import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { ServiceProvider} from '../model/service-provider';
import { Bankresponse} from '../model/bankresponse';


@Injectable({
  providedIn: 'root'
})
export class ServiceProviderService {

  baseUrl:string;
  result: Observable<ServiceProvider> ;
  

  constructor(private http: HttpClient) {
    this.baseUrl=`${environment.baseMwUrl}`;
  }
  add(sp:ServiceProvider):Observable<ServiceProvider>{
    console.log(sp);
    this.result= this.http.post<ServiceProvider>(`${this.baseUrl}/registeredDetails`,sp);

    return this.result;
  }
  
  getById(userId:String):Observable<ServiceProvider>{
    return this.http.get<ServiceProvider>(`${this.baseUrl}/loginDetails/${userId}`);
  }
  getPendingList():Observable<any>{
    return this.http.get<any>(`${this.baseUrl}/pendingList`)
  }

  getStatus(sp:ServiceProvider) : Observable<any>{
    return this.http.post<any>(`${this.baseUrl}/updateSP`,sp)
  }
}
