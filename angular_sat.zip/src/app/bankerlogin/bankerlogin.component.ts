import { Component, OnInit } from '@angular/core';
import { ServiceProvider } from '../model/service-provider';
import { ServiceProviderService } from '../service/service-provider.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-bankerlogin',
  templateUrl: './bankerlogin.component.html',
  styleUrls: ['./bankerlogin.component.css']
})
export class BankerloginComponent implements OnInit {
  submitted = false;
  bankers = ['Banker1', 'Banker2',
  'Banker3', 'Banker4'];
  serviceProviders:ServiceProvider[];
 

 

  constructor(private sPServ :ServiceProviderService,private router: Router) {
    this.serviceProviders=[];
   }

  ngOnInit() {
    this.submitted = false;
  }
  onSubmit() { this.submitted = true; }
  load() {
    this.sPServ.getPendingList().subscribe(
      (data) => {
        this.serviceProviders = data;
      }
    );
  }
//   getList(){
//     this.sPServ.getPendingList().subscribe(
//  (data) => {
//    this.serviceProviders=data;
//    this.router.navigateByUrl("pendinglist");
//  }
//     );
//   }

}
