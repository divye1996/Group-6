import { Component, OnInit } from '@angular/core';
import { ServiceProvider } from '../model/service-provider';
import { ServiceProviderService } from '../service/service-provider.service';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-splogin',
  templateUrl: './splogin.component.html',
  styleUrls: ['./splogin.component.css']
})
export class SploginComponent implements OnInit {
  userId: string;
  serviceProvider: ServiceProvider;
  constructor(private sPServ: ServiceProviderService,private router: Router)  {
    this.userId = "";
  this.serviceProvider = null;
  }

  ngOnInit() {
    this.login();
  }
  login() {
    localStorage.setItem('userId', this.userId);
 
    this.sPServ.getById(this.userId).subscribe(
 
      (data) => {
        this.serviceProvider = data;
        localStorage.setItem('serviceProvider', JSON.stringify(this.serviceProvider));
        this.router.navigateByUrl("welcome");
      }
      
    );
  }
  

 
}