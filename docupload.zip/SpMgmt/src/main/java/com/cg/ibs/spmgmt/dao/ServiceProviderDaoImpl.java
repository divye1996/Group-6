package com.cg.ibs.spmgmt.dao;

import java.io.File;
import java.io.FileInputStream;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;

import com.cg.ibs.spmgmt.bean.BankAdmin;
import com.cg.ibs.spmgmt.bean.ServiceProvider;
import com.cg.ibs.spmgmt.exception.IBSException;
import com.cg.ibs.spmgmt.exception.IBSExceptionInterface;
import com.cg.ibs.spmgmt.util.JPAUtil;
import com.sun.xml.txw2.Document;
 

public class ServiceProviderDaoImpl implements ServiceProviderDao {
	public static final Logger LOGGER = Logger.getLogger(ServiceProviderDaoImpl.class);
	private static EntityManager entityManager;	
	CriteriaQuery<ServiceProvider> query;
	Root<ServiceProvider> root;
	
	public ServiceProviderDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
		BankAdmin admin=new BankAdmin("bank1","pass1");
		entityManager.merge(admin);
		
		// criteria API Definition
		   CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		    query = criteriaBuilder.createQuery(ServiceProvider.class);
		    root = query.from(ServiceProvider.class);
	} 

	@Override
	public ServiceProvider addServiceProvider(ServiceProvider serviceProvider) throws IBSException {
		 entityManager.persist(serviceProvider);
		return serviceProvider;
	}

	@Override
	public ServiceProvider updateServiceProvider(ServiceProvider serviceProvider) throws IBSException {
		 return entityManager.merge(serviceProvider);
	}

	@Override
	public ServiceProvider getServiceProviderById(String userId) throws IBSException {
		 
		return entityManager.find(ServiceProvider.class, userId);
	}

	@Override
	public List<ServiceProvider> getServiceProviders() throws IBSException {
		List<ServiceProvider> list=null;
		TypedQuery<ServiceProvider> query=entityManager.createQuery("SELECT s from ServiceProvider s", ServiceProvider.class);
		try {
		list =query.getResultList();
		}
		catch(PersistenceException exception)  {
			throw new IBSException(IBSExceptionInterface.FETCHING_FAILED_MESSAGE);
			
		}
		return list;
	}

	@Override
	public List<ServiceProvider> getPendingServiceProviders() throws IBSException {
		List<ServiceProvider> list = null; 
		TypedQuery<ServiceProvider> query=entityManager.createQuery("SELECT s from ServiceProvider s where s.status='Pending'", ServiceProvider.class);
		try {
	    list = query.getResultList();
		}
		catch(PersistenceException exception) {
			throw new IBSException(IBSExceptionInterface.FETCHING_FAILED_MESSAGE);
		}
		return list;
	}

	@Override
	public List<ServiceProvider> getApprovedServiceProviders() throws IBSException {
		 List<ServiceProvider> list = null;
		TypedQuery<ServiceProvider> query=entityManager.createQuery("SELECT s from ServiceProvider s where s.status='Approved'",ServiceProvider.class);
	    try{
	    	list = query.getResultList();
	    }
	    catch(PersistenceException exception) {
	    	throw new IBSException(IBSExceptionInterface.FETCHING_FAILED_MESSAGE);
	    }
		return list;
	}

	@Override
	public List<ServiceProvider> getDisapprovedServiceProviders() throws IBSException {
		List<ServiceProvider> list = null;
		TypedQuery<ServiceProvider> query=entityManager.createQuery("SELECT s from ServiceProvider s where s.status='Disapproved'",ServiceProvider.class);
	    try{
	    	list =query.getResultList();
	    }
	    catch(PersistenceException exception) {
	    	throw new IBSException(IBSExceptionInterface.FETCHING_FAILED_MESSAGE);
	    }
		return list;
	}

	@Override
	public List<ServiceProvider> getApprovedDisapprovedServiceProviders() throws IBSException {
		List<ServiceProvider> list =null;
		TypedQuery<ServiceProvider> query=entityManager.createQuery("SELECT s from ServiceProvider s where s.status='Approved' or s.status ='Disapproved'",ServiceProvider.class);
	    try{
	         list =query.getResultList();
	    }
	    catch(PersistenceException exception) {
	    	throw new IBSException(IBSExceptionInterface.FETCHING_FAILED_MESSAGE);
	    }
		return list;
	}

	@Override
	public BankAdmin getBankAdmin(String adminId) throws IBSException {	
		List<BankAdmin> admins = null;
		TypedQuery<BankAdmin> query=entityManager.createQuery("SELECT s from BankAdmin s where s.adminID='"+adminId+"'",BankAdmin.class);
		try{
			admins=query.getResultList();
		}
		catch(PersistenceException exception) {
	    	throw new IBSException(IBSExceptionInterface.FETCHING_FAILED_MESSAGE);
	    }
		BankAdmin admin= new BankAdmin();
		if(admins.isEmpty()) {
			admin.setAdminID("adminId");
			admin.setAdminPassword("false");
		}
		else
		admin=admins.get(0);
		return admin;
	//	return entityManager.find(BankAdmin.class,adminId);
	}

	@Override
	public BigInteger getLastSPI() throws IBSException {
		BigInteger max_spi=null;
		TypedQuery<BigInteger> query=entityManager.createQuery("SELECT max(s.spi) from ServiceProvider s",BigInteger.class);
	     try{
	    	 max_spi =query.getSingleResult();
	     }
	     catch(PersistenceException exception) {
	     throw new IBSException(IBSExceptionInterface.FETCHING_FAILED_MESSAGE);
	     }
	     if(max_spi==null)max_spi=BigInteger.valueOf(-1);
		return max_spi ;
	}

	@Override
	public String checkUserId(String userId) throws IBSException {
		String userIdCheck = null;
		List<ServiceProvider> provider=null;
		TypedQuery<ServiceProvider> query=entityManager.createQuery("SELECT s from ServiceProvider s where s.userId='"+userId+"'",ServiceProvider.class);
//			userIdCheck = (String) query.setParameter("userId", userId).getSingleResult();
		try {
		provider=query.getResultList();
//			userIdCheck=entityManager.find(ServiceProvider.class, userId).getUserId();
		}catch(PersistenceException exception) {
			throw new IBSException(IBSExceptionInterface.FETCHING_FAILED_MESSAGE);
		}
		
			if(provider.isEmpty()) {userIdCheck="empty";}
			else {
				userIdCheck=userId;
			}
		return userIdCheck;	 		 
	}
	
}	
	
//	
//	public boolean uploadDocument(Document panCardUpload,ServiceProvider serviceProvider) throws IBSException {
//        LOGGER.info("Document being uploaded");
//        boolean isDone = false;
//        FileInputStream inputStream = null;
//        Query query = entityManager.createQuery("update s.panCardUpload from serviceProviders s where s");
//        if (null == inputStream) {
//        File uploadFile = new File(serviceProvider.getPathOfPanDocument());
//        inputStream = new FileInputStream(uploadFile);
//        
//        
//        
//        
//        Connection connection = OracleDataBaseUtil.getConnection();
//        try (PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.UPLOAD_DOCUMENT);) {
//            if (null == inputStream) {
//                File uploadFile = new File(document.getPathOfDocument());
//                inputStream = new FileInputStream(uploadFile);
//                preparedStatement.setBinaryStream(1, inputStream);
//                preparedStatement.setBigDecimal(2, new BigDecimal(loanMaster.getCustomerBean().getUCI()));
//                preparedStatement.executeUpdate();
//                isDone = true;
//                connection.commit();
//            }
//        } catch (SQLException exp) {
//            try {
//                throw new IBSException(ExceptionMessages.MESSAGEFORSQLEXCEPTION);
//            } catch (IBSException exp1) {
//                LOGGER.error("SQL Exception occuring while uploading document.");
//                System.out.println(exp1.getMessage());
//            }
//
// 
//
//        } catch (FileNotFoundException exp2) {
//            try {
//                throw new IBSException(ExceptionMessages.MESSAGEFORFILENOTFOUND);
//            } catch (IBSException exp31) {
//                LOGGER.error("FileNotFound Exception occuring while uploading document.");
//                System.out.println(exp31.getMessage());
//            }
//        } finally {
//            if (inputStream != null) {
//                try {
//                    inputStream.close();
//                } catch (IOException e) {
//                    try {
//                        throw new IBSException(ExceptionMessages.MESSAGEFORFILENOTFOUND);
//                    } catch (IBSException exp32) {
//                        LOGGER.error("FileNotFound Exception occuring while uploading document.");
//                        System.out.println(exp32.getMessage());
//                    }
//                }
//            }
//        }
//        return isDone;
//    }
//	
//	
//	public boolean downloadDocument(long applicationNumber) throws IBSException {
//        LOGGER.info("Document is being downloaded");
//        boolean check = false;
//        Connection connection = OracleDataBaseUtil.getConnection();
//        try (PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.DOWNLOAD_DOCUMENT);) {
//            preparedStatement.setLong(1, applicationNumber);
//            try (ResultSet resultSet = preparedStatement.executeQuery()) {
//                if (resultSet.next()) {
//                    Blob getDocument = resultSet.getBlob("document");
//                    FileOutputStream fileOutputStream = new FileOutputStream("./download" + applicationNumber + ".pdf");
//                    fileOutputStream.write(getDocument.getBytes(1, (int) getDocument.length()));
//                    fileOutputStream.flush();
//                    fileOutputStream.close();
//                    check = true;
//                }
//            } catch (FileNotFoundException e) {
//                try {
//                    throw new IBSException(ExceptionMessages.MESSAGEFORFILENOTFOUND);
//                } catch (IBSException exp12) {
//                    LOGGER.error("FileNotFound Exception occuring while downloading document.");
//                    System.out.println(exp12.getMessage());
//                }
//
// 
//
//            } catch (IOException e) {
//                try {
//                    throw new IBSException(ExceptionMessages.MESSAGEFORIOEXCEPTION);
//                } catch (IBSException exp12) {
//                    LOGGER.error("IO Exception occuring while downloading document.");
//                    System.out.println(exp12.getMessage());
//                }
//            }
//        } catch (SQLException e) {
//            try {
//                throw new IBSException(ExceptionMessages.MESSAGEFORSQLEXCEPTION);
//            } catch (IBSException exp12) {
//                LOGGER.error("SQL Exception occuring while downloading document.");
//                System.out.println(exp12.getMessage());
//            }
//        }
//        return check;
//    }
// 
//}
//	
	



	
	
	

 
 