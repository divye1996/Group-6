import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {DashboardComponent} from './dashboard/dashboard.component';
import {GroupsComponent} from './groups/groups.component';
import {ContactFormComponent} from './contact-form/contact-form.component';
import {SearchContactComponent} from './search-contact/search-contact.component';
import {ContactsListComponent} from './contacts-list/contacts-list.component';
import {OtherbankComponent} from './otherbank/otherbank.component';
import {NewIbsComponent} from './new-ibs/new-ibs.component';
import {ExistingIbsComponent} from './existing-ibs/existing-ibs.component';
import {SploginComponent} from './splogin/splogin.component';
import {BankerloginComponent} from './bankerlogin/bankerlogin.component';
import {DemoFormComponent} from './demo-form/demo-form.component';
// import {RegisteredDetailsComponent} from './registered-details/registered-details.component';



import { from } from 'rxjs';

const routes: Routes = [
  {path:'',component:DashboardComponent,pathMatch:'full'},
  {path:'groups',component:GroupsComponent},
  {path:'demoForm',component:DemoFormComponent},
  {path:'contacts',component:ContactsListComponent},
  {path:'newContact',component:ContactFormComponent},
  {path:'editContact/:contactId',component:ContactFormComponent},
  {path:'search',component:SearchContactComponent},
  {path:'otherbankregister',component:OtherbankComponent},
  {path:'newibsregister',component:NewIbsComponent},
  {path:'existingibsregister',component:ExistingIbsComponent},
  {path:'splogin',component:SploginComponent},
  {path:'bankerlogin',component:BankerloginComponent}
  // {path:'registered-details',component:RegisteredDetailsComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
