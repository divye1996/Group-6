import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bankerlogin',
  templateUrl: './bankerlogin.component.html',
  styleUrls: ['./bankerlogin.component.css']
})
export class BankerloginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
