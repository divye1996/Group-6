import { Component } from '@angular/core';
import { ServiceProvider } from '../model/service-provider';

@Component({
  selector: 'app-demo-form',
  templateUrl: './demo-form.component.html',
  styleUrls: ['./demo-form.component.css']
})
export class DemoFormComponent{

  serviceProvider=new ServiceProvider();
  submitted=false;
  categories=["Telecom","Finance","DTH"];
  powers = ['Really Smart', 'Super Flexible',
  'Super Hot', 'Weather Changer'];

  constructor() { }

  onSubmit(){
    this.submitted=true;
  }

  nice(){
    console.log("Assume Submitted");
  }

}