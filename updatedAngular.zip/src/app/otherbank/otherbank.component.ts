import { Component, OnInit } from '@angular/core';
import { ServiceProvider } from '../model/service-provider';
import {  ServiceProviderService } from '../service/service-provider.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-otherbank',
  templateUrl: './otherbank.component.html',
  styleUrls: ['./otherbank.component.css']
})
export class OtherbankComponent implements OnInit {
  serviceProviders : ServiceProvider[]; 
  serviceProvider : ServiceProvider;

  constructor(private sPServ: ServiceProviderService) {
    this.serviceProvider = new ServiceProvider;
  }

  ngOnInit() {
  }
  save() {

    this.sPServ.add(this.serviceProvider).subscribe(
      (data) => {
        this.serviceProvider = data;
      }
    );
  }

}
