package com.cg.ibs.spmgmt.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cg.ibs.spmgmt.bean.BankResponse;
import com.cg.ibs.spmgmt.bean.SPCustomerData;
import com.cg.ibs.spmgmt.bean.ServiceProvider;
import com.cg.ibs.spmgmt.exception.IBSException;
import com.cg.ibs.spmgmt.exception.RegisterException;
import com.cg.ibs.spmgmt.service.ServiceProviderService;

@RestController
@Scope("session")
public class DefaultController {

	@Autowired
	private ServiceProviderService service;

	@RequestMapping({ "/", "/home" })
	public String showHome() {
		return "homePage";
	}
	

//	@RequestMapping(value = "/errors",method = RequestMethod.GET)
//	public String showErrorPage(){
//		return "pageNotFound";
//	}

//	@RequestMapping(value = "/downloadAdd", method = RequestMethod.GET)
//	public ResponseEntity<ByteArrayResource> downloadAdd(@RequestParam("uid") String uid)
//			throws IOException, IBSException {
//		ServiceProvider provider = service.getServiceProvider(uid);
//		byte[] data = provider.getAddressProofUpload();
//		ByteArrayResource resource = new ByteArrayResource(data);
//		return ResponseEntity.ok()
//				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=Address_Doc_" + provider.getUserId())
//				.contentType(MediaType.APPLICATION_PDF).contentLength(data.length).body(resource);
//	}
//	
//	@RequestMapping(value = "/downloadPan", method = RequestMethod.GET)
//	public ResponseEntity<ByteArrayResource> downloadPan(@RequestParam("uid") String uid)
//			throws IOException, IBSException {
//		ServiceProvider provider = service.getServiceProvider(uid);
//		byte[] data = provider.getPanCardUpload();
//		ByteArrayResource resource = new ByteArrayResource(data);
//		return ResponseEntity.ok()
//				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=PAN_Doc_" + provider.getUserId())
//				.contentType(MediaType.APPLICATION_PDF).contentLength(data.length).body(resource);
//	}
//
//	@ExceptionHandler(IBSException.class)
//	public ModelAndView handleUserIdNotFoundException(HttpServletRequest request, IBSException message) {
//		return new ModelAndView("errorPage", "message", message.getMessage());
//
//	}

	 
	//Fresh Registration - Other Bank
	@PostMapping("/registeredDetails")
	public ResponseEntity<?> showDetailsOtherBank(@RequestBody ServiceProvider serviceProvider){
		
		ResponseEntity<?> result;
		
		try {
			serviceProvider = service.generateIdPassword(serviceProvider);
			  service.storeSPDetails(serviceProvider);
		} catch (RegisterException | IBSException e) {
			System.out.println(e.getMessage());
		}
		
		if(serviceProvider == null) {
			result = new ResponseEntity<String>("Internal Error",HttpStatus.BAD_REQUEST);
		}
		else {
			result = new ResponseEntity<ServiceProvider>(serviceProvider, HttpStatus.OK);
		}
		return result;
	}

	//Pre-existing IBS Customer
	@PostMapping("/registeredDetailsAlready")
	public ResponseEntity<ServiceProvider> showDetailsAlreadyExisting(@RequestBody ServiceProvider serviceProvider){
		
		ResponseEntity<ServiceProvider> result;
		serviceProvider.setPanNumber("LUUPSA56907");
		serviceProvider.setAccountNumber(new BigInteger("10000010000"));
		serviceProvider.setIFSC("IBS0000789");
		serviceProvider.setBankName("IBS limited");
		
		
		try {
			serviceProvider = service.generateIdPassword(serviceProvider);
			  service.storeSPDetails(serviceProvider);
		} catch (RegisterException | IBSException e) {
			e.printStackTrace();
		}
		
		if(serviceProvider == null) {
			result = new ResponseEntity<ServiceProvider>(HttpStatus.BAD_REQUEST);
		}
		else {
          
			result = new ResponseEntity<ServiceProvider>(serviceProvider, HttpStatus.OK);
		}
		
		return result;
	}
	 
	//New IBS Bank Registration
	@PostMapping("/registeredDetailsOurBank")
	public ResponseEntity<ServiceProvider> showDetailsOurBank(@RequestBody ServiceProvider serviceProvider){
		
		ResponseEntity<ServiceProvider> result;
		serviceProvider.setPanNumber("LUUPSA56907");
		serviceProvider.setAccountNumber(new BigInteger("10000010000"));
		serviceProvider.setIFSC("IBS0000789");
		serviceProvider.setBankName("IBS limited");
		
		try {
			serviceProvider = service.generateIdPassword(serviceProvider);
			  service.storeSPDetails(serviceProvider);
		} catch (RegisterException | IBSException e) {
			e.printStackTrace();
		}
		
		if(serviceProvider == null) {
			result = new ResponseEntity<ServiceProvider>(HttpStatus.BAD_REQUEST);
		}
		else {
          
			result = new ResponseEntity<ServiceProvider>(serviceProvider, HttpStatus.OK);
		}
		
		return result;
	}
	
	
	@GetMapping("/loginDetails/{userId}")
	public ResponseEntity<ServiceProvider> showLoginDetails(@PathVariable String userId) throws IBSException{
		
		ResponseEntity<ServiceProvider> result;
		ServiceProvider serviceProvider = null;
		serviceProvider = service.getServiceProvider(userId);
		System.out.println(userId);
		System.out.println(serviceProvider.toString());
		
		if(serviceProvider == null) {
			result = new ResponseEntity<ServiceProvider>(HttpStatus.BAD_REQUEST);
		}
		else {
          
			result = new ResponseEntity<ServiceProvider>(serviceProvider, HttpStatus.OK);
		}
		
		
		return result;
	}

//
//	@RequestMapping("/loginDetails")
//	public ModelAndView showLoginDetails(@RequestParam("userId") String userId) throws IBSException {
//		ServiceProvider serviceProvider = new ServiceProvider();
//
//		try {
//			serviceProvider = service.getServiceProvider(userId);
//		} catch (IBSException e) {
//			System.out.println(e.getMessage());
//		}
//
//		if (serviceProvider == null) {
//			throw new IBSException(IBSExceptionInterface.INCORRECT_USERID_MESSAGE);
//		}
//		return new ModelAndView("loginDetails", "serviceProvider", serviceProvider);
//	}
//	public List<String> formatResponse(List<ServiceProvider> serviceProviders){
//		List<String> formatResponse=new ArrayList<String>();
//		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
//		int index = 1;
//
//		formatResponse.add((new String("Name of Company")).format("%-25s"));
//		formatResponse.add((new String("Category")).format("%-25s"));
//		formatResponse.add((new String("User_ID")).format("%-25s"));
//		formatResponse.add((new String("Request Time")).format("%-25s"));
////		System.out.format("%-20s", "Name of company");
////		System.out.format("%-25s", "Category");
////		System.out.format("%-20s", "USER_ID ");
////		System.out.format("%-20s\n", " Request Date and Time");
//		for (ServiceProvider serviceProvider : serviceProviders) {
//			formatResponse.add((new String()).format(format, args));
//			System.out.format("%-20s", index + "." + serviceProvider.getNameOfCompany());
//			System.out.format("%-25s", serviceProvider.getCategory());
//			System.out.format("%-20s", serviceProvider.getUserId());
//			System.out.format("%-20s\n", serviceProvider.getRequestDate().format(format));
//			index++;
//		}
//		
//		formatResponse.add(null);
//		return null;
//	}
// 

	
	@GetMapping("/pendingList")
	public ResponseEntity<?> showPendingList() {

		ResponseEntity<?> result=new ResponseEntity<String>("Internal Error",HttpStatus.BAD_REQUEST);; 
		List<ServiceProvider> pendingList = null;
		try {

			pendingList = service.showPending();
			result=new ResponseEntity<List<ServiceProvider>>(pendingList,HttpStatus.OK);
		} catch (IBSException e) {
			String msg = e.getMessage();
			System.out.println(msg);
		}
		return result;
	}

	
	@GetMapping("/approvedDisapprovedHistory")
	public ResponseEntity<?> showApprovedDisapprovedList() {
		ResponseEntity<?> result=new ResponseEntity<String>("Internal Error",HttpStatus.BAD_REQUEST);; 
		List<ServiceProvider> approvedDisapprovedList = null;
		try {

			approvedDisapprovedList = service.showHistory();
			result=new ResponseEntity<List<ServiceProvider>>(approvedDisapprovedList,HttpStatus.OK);
		} catch (IBSException e) {
			String msg = e.getMessage();
			System.out.println(msg);
		}
		return result;
	}

	@GetMapping("/showDetailsToApprove/{userId}")
	public ResponseEntity<?> updateStatusMethod(@PathVariable String userId) {
		ResponseEntity<?> result=new ResponseEntity<String>("Internal Error",HttpStatus.BAD_REQUEST);; 
		ServiceProvider serviceProvider = null;
		try {
			serviceProvider = service.getServiceProvider(userId);
			result=new ResponseEntity<ServiceProvider>(serviceProvider,HttpStatus.OK);
		} catch (IBSException e) {
			String msg = e.getMessage();
			System.out.println(msg);
		}
		return result;
	}

	@PostMapping("/updateSP")
	public ResponseEntity<?> updateSP(@RequestBody BankResponse response ) {
		ResponseEntity<?> result=new ResponseEntity<String>("Internal Error",HttpStatus.BAD_REQUEST);
		System.out.println(response.toString());
		try {
			ServiceProvider provider = service.getServiceProvider(response.getUserId());
			System.out.println(provider);
			provider.setRemarks(response.getRemarks());
			service.approveSP(provider, response.getDecision());
			result=new ResponseEntity<String>("Status Updated Succesfully",HttpStatus.OK);
		} catch (IBSException e) {
			String msg = e.getMessage();
			System.out.println(msg);
		}
		return result;
	}
	
	@PostMapping("/up")
	public String uploadBills(@RequestParam("bills") MultipartFile bills) throws IOException {
		byte[] bytes=bills.getBytes();
		String s=new String(bytes);
		System.out.println(s);
		BufferedReader csvReader = new BufferedReader(new StringReader(s));
		String row;
		ServiceProvider serviceProvider=new ServiceProvider();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		while ((row = csvReader.readLine()) != null) {
			String[] data = row.split(",");
			if (data.length == 0)
				break;
			SPCustomerData spCustomerData = new SPCustomerData();
			spCustomerData.setServiceProvider(serviceProvider);
			spCustomerData.setSpcId(data[0]);
			spCustomerData.setBillDate(LocalDate.parse(data[1], formatter));
			spCustomerData.setDueDate(LocalDate.parse(data[2], formatter));
			spCustomerData.setBillAmount(Double.valueOf(data[3]));
			service.storeSPCustomerData(spCustomerData);
			System.out.println(spCustomerData.toString());
		}
		csvReader.close();
		System.out.println("Upload Succesfull. Bills Updated");
		return s;
	}
	
	@PostMapping("/down")
	public String displayBills(@RequestParam("uid") String uid) {
		SPCustomerData data=new SPCustomerData();
//		ServiceProvider serviceProvider=service.getServiceProvider();
//		data=service.getSPCustomerData(serviceProvider);
		System.out.println(data.toString());
		return (data.toString()+uid);
	}
}
