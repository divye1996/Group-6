package com.cg.ibs.spmgmt.dao;

import java.math.BigInteger;
import java.util.ArrayList;

import com.cg.ibs.spmgmt.bean.BankAdmin;
import com.cg.ibs.spmgmt.bean.ServiceProvider;
import com.cg.ibs.spmgmt.exception.IBSException;

public interface ServiceProviderDao {
	ServiceProvider addServiceProvider(ServiceProvider serviceProvider) throws IBSException;

	ServiceProvider updateServiceProvider(ServiceProvider serviceProvider) throws IBSException;

	ServiceProvider getServiceProviderById(String userId) throws IBSException;

	ArrayList<ServiceProvider> getServiceProviders() throws IBSException;

	ArrayList<ServiceProvider> getPendingServiceProviders() throws IBSException;

	ArrayList<ServiceProvider> getApprovedServiceProviders() throws IBSException;

	ArrayList<ServiceProvider> getDisapprovedServiceProviders() throws IBSException;

	ArrayList<ServiceProvider> getApprovedDisapprovedServiceProviders() throws IBSException;

	BankAdmin getBankAdmin(String bankId) throws IBSException;

	BigInteger getLastSPI() throws IBSException;
	
	String checkUserId(String userId);

}
