import { Component, OnInit } from '@angular/core';
import { ServiceProvider } from '../model/service-provider.model';
import { SpService } from '../service/sp.service';
 
@Component({
  selector: 'app-banker',
  templateUrl: './banker.component.html',
  styleUrls: ['./banker.component.css']
})
export class BankerComponent implements OnInit {
  submitted = false;
  bankers = ['Banker1', 'Banker2',
  'Banker3', 'Banker4'];
  serviceProviders:ServiceProvider[];
 
 
 
 
  constructor(private sPService :SpService) {
    this.serviceProviders=[];
   }
 
  ngOnInit() {
    this.submitted = false;
  }
  onSubmit() { this.sPService.bankSubmit = true; }
  // load() {
  //   this.sPService.getPendingList().subscribe(
  //     (data) => {
  //       this.serviceProviders = data;
  //     }
  //   );
  // }
 
}

// import { Component, OnInit } from '@angular/core';
// import { Router } from '@angular/router';

// @Component({
//   selector: 'app-banker',
//   templateUrl: './banker.component.html',
//   styleUrls: ['./banker.component.css']
// })
// export class BankerComponent implements OnInit {

//   constructor(private router: Router) { }

//   ngOnInit() {
//   }

//   bankerLogin(){
//     this.router.navigateByUrl("welcome");
//   }

// }
