package com.cg.ibs.spmgmt.dao;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import com.cg.ibs.spmgmt.bean.BankAdmin;
import com.cg.ibs.spmgmt.bean.ServiceProvider;
import com.cg.ibs.spmgmt.exception.IBSException;

public class ServiceProviderDaoImpl implements ServiceProviderDao {
	 
	
	BankAdmin admin1=new BankAdmin("company@ID", "65F43S6");
	 BankAdmin admin2=new BankAdmin("company@ID2", "65F43S8");
	// DataBase
	private static Map<String, ServiceProvider> spMap = new HashMap<>();
	
	private static Map<String, BankAdmin> bankMap = new HashMap<>();

	
	{
		bankMap.put(admin1.getAdminID(), admin1);
		bankMap.put(admin2.getAdminID(), admin2);
	}
	@Override
	public boolean storeServiceProviderData(ServiceProvider serviceProvider) throws IBSException {
		
		if (serviceProvider != null && !(spMap.containsKey(serviceProvider.getUserId()))) {
			spMap.put(serviceProvider.getUserId(), serviceProvider);
			return true;
		} else {
			throw new IBSException("UID doesn't or object passed is null");
		}

	}

	@Override
	public TreeMap<LocalDateTime,ServiceProvider> fetchPendingSp() {
		TreeMap<LocalDateTime,ServiceProvider> tempPendingList = new TreeMap<>();
		int i=0;
		System.out.println("entered method");
		System.out.println(spMap.containsKey("id"));
		for (ServiceProvider serviceProvider : spMap.values()) {
			System.out.println(++i);
			System.out.println("in for");
			if (serviceProvider.getStatus().equalsIgnoreCase("pending")) {
				System.out.println("satisfied if");
				System.out.println(serviceProvider.getRequestDate());
				System.out.println(serviceProvider.toString());
				tempPendingList.put(serviceProvider.getRequestDate(), serviceProvider);
			}
			System.out.println("out of if");

		}
		System.out.println("out of for");
		return tempPendingList;

	}

	@Override
	public ServiceProvider checkLogin(String userId, String password) throws IBSException {
		ServiceProvider returnService=null;
		for (ServiceProvider serviceProvider : spMap.values()) {
			if (serviceProvider.getUserId().equals(userId)) {
				if (serviceProvider.getPassword().equals(password)) {
					returnService= serviceProvider;
				} 
				else {
					throw new IBSException("INCORRECT PASSWORD");
				}
			} 
			else {
				throw new IBSException("INCORRECT USERID");
			}
			
		}
		return returnService;
	}

	@Override
	public void approveStatus(ServiceProvider serviceProvider) throws IBSException {
			spMap.replace(serviceProvider.getUserId(), serviceProvider);
		}

	@Override
	public boolean checkUserID(String userId) throws IBSException {
		boolean result;
		if(spMap.containsKey(userId)){
			result= false;
		}
		else
			result=true;
		return result;
	}

	

	@Override
	public TreeMap<LocalDateTime, ServiceProvider> fetchApprovedSp() {
		TreeMap<LocalDateTime,ServiceProvider> tempApprovedList = new TreeMap<>();
		for (ServiceProvider serviceProvider : spMap.values()) {
			if (serviceProvider.getStatus().equalsIgnoreCase("Approved")) {
				tempApprovedList.put(serviceProvider.getRequestDate(), serviceProvider);
			}

		}
		return tempApprovedList;
	}

	public boolean checkAdminLogin(String adminID, String adminPassword) throws IBSException {
	    boolean result = false;
		for(BankAdmin bankAdmin:bankMap.values())
		{
			if(bankAdmin.getAdminID().equals(adminID)&&bankAdmin.getAdminPassword().equals(adminPassword))
			{
				result=true;
			}
		}
		return result;
		
	}

	

	@Override
	public ServiceProvider getServiceProvider(String uid) throws IBSException {
	
		if(spMap.containsKey(uid)){
			return spMap.get(uid);
		}
		return null;
		
	}

}


