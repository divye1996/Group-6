package com.cg.ibs.spmgmt.service;



import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Random;
import java.util.TreeMap;
import java.math.BigInteger;
import java.time.LocalDateTime;

import com.cg.ibs.spmgmt.bean.BankAdmin;
import com.cg.ibs.spmgmt.bean.ServiceProvider;
import com.cg.ibs.spmgmt.dao.ServiceProviderDao;
import com.cg.ibs.spmgmt.dao.ServiceProviderDaoImpl;
import com.cg.ibs.spmgmt.exception.IBSException;
import com.cg.ibs.spmgmt.exception.*;

public class ServiceProviderServiceImpl implements ServiceProviderService {
		ServiceProviderDaoImpl obj = new ServiceProviderDaoImpl();
		
	@Override	
	public ServiceProvider generateIdPassword(ServiceProvider serviceprovider) throws RegisterException {
//		String s = serviceprovider.getNameOfCompany();
//		String userId = s.substring(0, 5);
//
//		String values = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*_=+-/.?<>)";
//
//		Random rndm_method = new Random();
//
//		char[] password = new char[8];
//
//		for (int i = 0; i < 8; i++) {
//			password[i] = values.charAt(rndm_method.nextInt(values.length()));
//		}
//
//		String result = password.toString();
//		serviceprovider.setUserId(userId);
//		serviceprovider.setPassword(result);
		serviceprovider.setUserId("id");
		serviceprovider.setPassword("password");
		return serviceprovider;
	}
	
	@Override
	public boolean storeSPDetails(ServiceProvider sp)throws IBSException{
		LocalDateTime requestDate=LocalDateTime.now();
		boolean result=false;
		sp.setRequestDate(requestDate);
		boolean storeResult=obj.storeServiceProviderData(sp);			//used to store the SP details after registration
		if(storeResult==true)
			result=true;
		return result;
	}

	@Override
	public boolean validateLogin(String username, String password) throws IBSException {
		System.out.println("bow  bow");
		boolean hj=false;
		ServiceProvider sp=new ServiceProvider();
		try
		{
			hj= obj.checkLogin(username, password) != null;
			}
		catch(IBSException e){
			System.out.println(e.getMessage());
		}//Exception catch block to be made in UI
		return hj;
	}
	
	public ServiceProvider getServiceProvider( String userid) throws IBSException{
		ServiceProvider sp= new ServiceProvider();
		sp= obj.getServiceProvider(userid);
		return sp;
	}

//	public String statusCheck(String userId) {
//		String status= new String("Pending");
//		obj.fetchPendingSp();
//		
//		return status;
//		}

	public TreeMap<LocalDateTime, ServiceProvider> showPending() {
		TreeMap<LocalDateTime,ServiceProvider> serviceProviders = obj.fetchPendingSp();
		return serviceProviders;
		
	}

	public void approveSP(ServiceProvider sp, boolean decision){
		
		generateSpi(sp);
		
	}

//	public void showApproved(String ServiceProvider[]) {
//
//	}

	public String[] getRegisteredSpName() {
		return null;
	}

	public BigInteger[] getRegisteredAcNo() {
		return null;
	}

	public String[] getAssignedSpi() {
		return null;
	}
	
	private BigInteger generateSpi(ServiceProvider sp){
		BigInteger spi= sp.getSpi();
		
		
		
		
		return spi;
	}

	

	@Override
	public TreeMap<LocalDateTime, ServiceProvider> getApprovedDetails() {
		// TODO Auto-generated method stub
		return null;
	}

}
