package com.cg.ibs.spmgmt.ui;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

import com.cg.ibs.spmgmt.bean.BankAdmin;
import com.cg.ibs.spmgmt.bean.ServiceProvider;
import com.cg.ibs.spmgmt.exception.IBSException;
import com.cg.ibs.spmgmt.exception.RegisterException;
import com.cg.ibs.spmgmt.service.ServiceProviderService;
import com.cg.ibs.spmgmt.service.ServiceProviderServiceImpl;

public class Application {

	public void menu() {
		System.out.println("Welcome to Service Provider Portal");
		System.out.println("Select an option below (1/2/3/4):");
		System.out.println("1. New Registration");
		System.out.println("2. Login");
		System.out.println("3. Bank Administrator Login");
		System.out.println("4. Exit");

	}

	public ServiceProvider getKYC(Scanner scanner, ServiceProvider serviceProvider) {

		System.out.println("Enter GST Number: ");
		serviceProvider.setGstin(scanner.next());
		System.out.println("Enter PAN: ");
		serviceProvider.setPanNumber(scanner.next());
		System.out.println("Enter Bank Account Number: ");
		serviceProvider.setAccountNumber(scanner.nextBigInteger());
		System.out.println("Enter Name of the Bank: ");
		serviceProvider.setBankName(scanner.next());
		System.out.println("Enter Company Address: ");
		serviceProvider.setCompanyAddress(scanner.next());
		System.out.println("Enter Contact Number: ");
		serviceProvider.setMobileNumber(scanner.nextBigInteger());
		return serviceProvider;

	}

	public ServiceProvider loginMenu(Scanner scanner, ServiceProvider serviceProvider) {
		System.out.println("Enter User ID: ");
		serviceProvider.setUserId(scanner.next());
		System.out.println("Enter Password: ");
		System.out.println("wrth");
		serviceProvider.setPassword(scanner.next());
		System.out.println("after");
		return serviceProvider;
	}

	public BankAdmin bankAdmin(Scanner scanner, BankAdmin admin) {
		System.out.println("Enter Admin ID: ");
		admin.setAdminID(scanner.next());
		System.out.println("Enter Password: ");
		admin.setAdminPassword(scanner.next());
		return admin;
	}

	public static void printDetails(ServiceProvider serviceProvider) {
		System.out.println("Name of Company: " + serviceProvider.getNameOfCompany());
		System.out.println("GST Number: " + serviceProvider.getGstin());
		System.out.println("PAN: " + serviceProvider.getPanNumber());
		System.out.println("Account Number: " + serviceProvider.getAccountNumber());
		System.out.println("Bank Name:" + serviceProvider.getBankName());
		System.out.println("Company Address: " + serviceProvider.getCompanyAddress());
		System.out.println("Mobile Number: " + serviceProvider.getMobileNumber());
	}

	public void showAllNames(TreeMap<LocalDateTime, ServiceProvider> serviceProviders, Scanner scanner,
			ServiceProviderService service) {
		int i = 1;

		System.out.println("Select an Account from the list below");

		do {
			for (Entry<LocalDateTime, ServiceProvider> entry : serviceProviders.entrySet()) {
				LocalDateTime key = entry.getKey();
				ServiceProvider value = entry.getValue();
				System.out.println(i + ". " + value.getNameOfCompany() + key);
				i++;
			}
			int k = scanner.nextInt();
			i = 1;
			for (Entry<LocalDateTime, ServiceProvider> entry : serviceProviders.entrySet()) {
				if (k == i) {
					ServiceProvider serviceProvider = entry.getValue();
					printDetails(serviceProvider);
					System.out.println("Enter 1 to Approve 2 to Disapprove");
					service.approveSP(serviceProvider, scanner.nextBoolean());
					serviceProviders.remove(entry);
				}
				i++;
			}

		} while (true);

	}

	public static void main(String[] args) {
		Application application = new Application();
		Scanner scanner = new Scanner(System.in);
		
		BankAdmin admin = new BankAdmin();

		boolean exitTrigger = true;
		do {
			ServiceProviderService service = new ServiceProviderServiceImpl();
			ServiceProvider serviceProvider = new ServiceProvider();
			application.menu();

			switch (scanner.nextInt()) {
			case 1:
				System.out.println("Enter Name of the Company");
				serviceProvider.setNameOfCompany(scanner.next());
				// call service interface method to generate Id password
				try {
					serviceProvider = service.generateIdPassword(serviceProvider);
				} catch (RegisterException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				// method(serviceProvider)
				System.out.println("User ID:" + serviceProvider.getUserId());
				System.out.println("Password: " + serviceProvider.getPassword());
				serviceProvider = application.getKYC(scanner, serviceProvider);
				System.out.println(serviceProvider.toString());
				// call service provider method to store the object into
				// database
				try {
					service.storeSPDetails(serviceProvider);
				} catch (IBSException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("Enter 1 to return to main menu");
				if (scanner.nextInt() == 1) {
					break;
				}
				break;

			case 2:
				// serviceProvider = application.loginMenu(scanner,
				// serviceProvider);
				System.out.println("Enter User ID: ");
				String inputId = scanner.next();
				System.out.println("Enter Password: ");
				// scanner.nextLine();
				String inputPassword = scanner.next();
				System.out.println("input taken :" + inputPassword);

				// call login validity and reassign serviceProvider
				try {

					System.out.println("id match" + service.validateLogin(inputId, inputPassword));
				} catch (IBSException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println(serviceProvider.toString());
				System.out.println("Approval Status: " + serviceProvider.getStatus());
				if (serviceProvider.getStatus().equals("Approved")) {
					System.out.println(serviceProvider.getSpi());
				}
				System.out.println("Press 1 to return to main menu");
				if (scanner.nextInt() == 1) {
					break;
				}
				break;

			case 3:
				admin = application.bankAdmin(scanner, admin);
				//
				System.out.println("List of Pending Accounts: ");
				TreeMap<LocalDateTime, ServiceProvider> serviceProviders = new TreeMap<>();
				serviceProviders = service.showPending();
				int i = 1;

				System.out.println("Select an Account from the list below");
				boolean exitTrigger2 = true;

				do {
					Set<LocalDateTime> keyz = serviceProviders.keySet();
					for (LocalDateTime key : keyz) {
						ServiceProvider value = serviceProviders.get(key);
						System.out.println(i + ". " + value.getNameOfCompany() + key);
						i++;

					}
					int k = scanner.nextInt();
					i = 1;
					for (LocalDateTime key : keyz) {
						if (k == i) {
							ServiceProvider value = serviceProviders.get(key);
							printDetails(value);
							System.out.println("Enter true to Approve false to Disapprove");
							service.approveSP(serviceProvider, scanner.nextBoolean());
							serviceProviders.remove(key);
						}
						i++;
						System.out.println("Enter false to exit/true to continue");
						exitTrigger2 = scanner.nextBoolean();
					}

				} while (exitTrigger2);
				// application.showAllNames(serviceProviders, scanner,service);
				System.out.println("Press 1 to return to main menu");
				if (scanner.nextInt() == 1) {
					break;

				}
			case 4:
				exitTrigger = false;
				break;

			default:
				System.out.println("Invalid Input");

			}
		} while (exitTrigger);

	}

}
