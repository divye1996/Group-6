package com.cg.ibs.spmgmt.exception;

public class IBSException extends Exception  {
	private static final long serialVersionUID = 4664456874499611218L;
	public IBSException(String message) {
		super(message);
	}

}
