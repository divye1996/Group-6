package com.cg.ibs.spmgmt.exception;

public interface IBSExceptionInterface {
	public static String alreadyExistMessage  = "Username already exists. Change username and try Registration again!";
	public static String incorrectPasswordMessage  = "INCORRECT PASSWORD";
	public static String incorrectUserIdMessage  ="INCORRECT USERID / PASSWORD ";
	
}
