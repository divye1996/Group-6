package com.cg.ibs.spmgmt.service;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.List;

import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.spmgmt.bean.BankAdmin;
import com.cg.ibs.spmgmt.bean.SPCustomerData;
import com.cg.ibs.spmgmt.bean.ServiceProvider;
import com.cg.ibs.spmgmt.dao.ServiceProviderDao;
import com.cg.ibs.spmgmt.dao.ServiceProviderDaoImpl;
import com.cg.ibs.spmgmt.exception.IBSException;
import com.cg.ibs.spmgmt.exception.IBSExceptionInterface;
import com.cg.ibs.spmgmt.exception.RegisterException;
import com.cg.ibs.spmgmt.util.JPAUtil;

@Service
public class ServiceProviderServiceImpl implements ServiceProviderService {
	public static final Logger LOGGER = Logger.getLogger(ServiceProviderServiceImpl.class);
	private static BigInteger spi = BigInteger.valueOf(-1);
	
	ServiceProvider serviceProvider;
	

	
	private ServiceProviderDao serviceProviderDao;
	
	@Autowired
	public ServiceProviderServiceImpl(ServiceProviderDao serviceProviderDao) {
		super();
		this.serviceProviderDao = serviceProviderDao;
	}

	public ServiceProviderDao getServiceProviderDao() {
		return serviceProviderDao;
	}

	public void setServiceProviderDao(ServiceProviderDao serviceProviderDao) {
		this.serviceProviderDao = serviceProviderDao;
	}

		// constructor
//	public ServiceProviderServiceImpl() {

	public boolean isRunnable() {
		boolean runnable = true;
		try {
		EntityTransaction entityTransaction = JPAUtil.getTransaction();
		if (!entityTransaction.isActive()) {
			entityTransaction.begin();
		}
			spi = serviceProviderDao.getLastSPI();
			entityTransaction.commit();
		} catch (ExceptionInInitializerError exception) {
			runnable = false;
			LOGGER.fatal("DATABASE NOT FOUND/CONNECTION FAILURE");
		} catch (IBSException exception) {
			System.out.println(exception.getMessage());
		}
		if (spi.compareTo(BigInteger.valueOf(100000)) < 0) {
			spi = BigInteger.valueOf(100000);
		}
		return runnable;
	}


	// Function to generate User ID and Password of Service Provider
	@Override
	public ServiceProvider generateIdPassword(ServiceProvider serviceProvider) throws RegisterException, IBSException {
		String temp = serviceProvider.getNameOfCompany();
		String userId = temp.substring(0,Math.min(temp.length(),5));
		boolean userIdExists = false;
		long tail = 1;
		EntityTransaction entityTransaction = JPAUtil.getTransaction();
		entityTransaction.begin();

		if (userIdExists = ((serviceProviderDao.checkUserId(userId)).equals(userId))) {
			String tempuser = userId;
				LOGGER.debug("User exsists");
			do {
				userId = tempuser + "_" + Long.toString(tail);
				userIdExists = ((serviceProviderDao.checkUserId(userId)).equals(userId));
				
				tail++;
			} while (userIdExists);
		}
		entityTransaction.commit();

		String passGeneratorSet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789" + "abcdefghijklmnopqrstuvxyz"
				+ "!@#$%^&*_=+-/.?<>)";
		StringBuilder userPass = new StringBuilder(8);

		for (int i = 0; i < 8; i++) {
			int index = (int) (passGeneratorSet.length() * Math.random());
			userPass.append(passGeneratorSet.charAt(index));
		}

		String result = userPass.toString();
		serviceProvider.setUserId(userId);
		serviceProvider.setPassword(result);
		return serviceProvider;
	}

	// Function to store details of Service Provider
	@Override
	public boolean storeSPDetails(ServiceProvider sp) throws RegisterException, IBSException {
		boolean result = false;
		if (sp == null) {
			throw new IBSException("No Service Provider Passed");
		}
		sp.setRequestDate(LocalDateTime.now());
		EntityTransaction entityTransaction = JPAUtil.getTransaction();
		entityTransaction.begin();
		ServiceProvider storeResult = serviceProviderDao.addServiceProvider(sp); // used to store the SP details after
		if(storeResult != null) {
			LOGGER.debug("successfully added");}
		entityTransaction.commit(); // // registration
		if (storeResult != null)
			result = true;
		return result;
	}

	// Function to validate Login of Service Provider
	@Override
	public boolean validateLogin(String username, String password) throws IBSException {
		boolean result = false;

		EntityTransaction entityTransaction = JPAUtil.getTransaction();
		if (!entityTransaction.isActive()) {
			entityTransaction.begin();
		}
		serviceProvider = serviceProviderDao.getServiceProviderById(username);
		entityTransaction.commit();
		if (serviceProvider != null) {
			if (serviceProvider.getPassword() != null) {
				if (password.equals(serviceProvider.getPassword())) {
					result = true;
				} else {
					throw new IBSException(IBSExceptionInterface.INCORRECT_LOGIN_MESSAGE);
				}
			} else {
				throw new IBSException(IBSExceptionInterface.INCORRECT_LOGIN_MESSAGE);
			}
		} else {
			throw new IBSException(IBSExceptionInterface.INCORRECT_LOGIN_MESSAGE);
		}
		return result;
	}

	// Function to get the details of Service Provider from DAO Layer where the
	// details are stored
	@Override
	public ServiceProvider getServiceProvider(String userid) throws IBSException {

		EntityTransaction entityTransaction = JPAUtil.getTransaction();
		entityTransaction.begin();
		serviceProvider = serviceProviderDao.getServiceProviderById(userid);
		entityTransaction.commit();
		return serviceProvider;
	}

	// Function to show all the Pending Request of Service Providers to the Bank
	// Administrative
	@Override
	public List<ServiceProvider> showPending() throws IBSException {
		return serviceProviderDao.getPendingServiceProviders();
	}

	// Function to approve or disapprove the request of Service Provider by the Bank
	// Administrative
	@Override
	public void approveSP(ServiceProvider sp, boolean decision) throws IBSException {
		if (decision) {
			sp.setStatus("Approved");
			generateSpi();
			sp.setSpi(spi);
		} else {
			sp.setStatus("Disapproved");
		}

		EntityTransaction entityTransaction = JPAUtil.getTransaction();
		entityTransaction.begin();
		serviceProviderDao.updateServiceProvider(sp);
		entityTransaction.commit();
	}

	// Function to generate Unique SPI ID after the Service Provider gets approved
	private static BigInteger generateSpi() {
		spi = spi.add(BigInteger.valueOf(1));
		return spi;
	}

	// Function to validate the login of bank Administrative
	@Override
	public boolean validateAdminLogin(String adminID, String adminPassword) throws IBSException {
		boolean validity = false;
		BankAdmin admin;
		EntityTransaction entityTransaction = JPAUtil.getTransaction();
		// entityTransaction.begin();
		if (!entityTransaction.isActive()) {
			entityTransaction.begin();
		}
		admin = serviceProviderDao.getBankAdmin(adminID);
		entityTransaction.commit();
		if (admin.getAdminPassword() != null) {
			if (adminPassword.equals(admin.getAdminPassword())) {
				validity = true;
			} else {
				throw new IBSException(IBSExceptionInterface.INCORRECT_LOGIN_MESSAGE);
			}
		} else {
			throw new IBSException(IBSExceptionInterface.INCORRECT_LOGIN_MESSAGE);
		}
		return validity;
	}

	// Default empty data function
	@Override
	public boolean emptyData() throws IBSException {
		EntityTransaction entityTransaction = JPAUtil.getTransaction();
		entityTransaction.begin();
		boolean result = (serviceProviderDao.getPendingServiceProviders().isEmpty());
		entityTransaction.commit();
		return result;

	}

	@Override
	public List<ServiceProvider> showHistory() throws IBSException {
		List<ServiceProvider> historyList=null;
		try {
		EntityTransaction entityTransaction = JPAUtil.getTransaction();
		entityTransaction.begin();
		historyList = serviceProviderDao.getApprovedDisapprovedServiceProviders();
		entityTransaction.commit();
		Collections.sort(historyList, (serviceProvider1, serviceProvider2) -> serviceProvider1.getRequestDate()
				.compareTo(serviceProvider2.getRequestDate()));
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return historyList;
	}

	@Override
	public void storeSPCustomerData(SPCustomerData customerData) {
		EntityTransaction entityTransaction = JPAUtil.getTransaction();
		if (!entityTransaction.isActive()) {
			entityTransaction.begin();
		}
		serviceProviderDao.addSPCustomerData(customerData);
		entityTransaction.commit();
	}

	@Override
	public List<SPCustomerData> getSPCustomerData(ServiceProvider serviceProvider) throws IBSException {
		List<SPCustomerData> data=serviceProviderDao.getSPData(serviceProvider);
		return data;
	}
}
